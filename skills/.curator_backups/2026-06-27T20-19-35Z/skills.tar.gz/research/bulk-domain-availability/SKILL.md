---
name: bulk-domain-availability
description: "Bulk-check domain availability across TLDs using raw WHOIS queries. Covers pattern generation (AABB, ABAB, AAAB, ABBB), parallel checking with ThreadPoolExecutor, organization by pattern and TLD, and suggestions for alternatives when premium patterns are exhausted."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [domain, whois, availability, research, bulk]
    related_skills: [cloudflare]
---

# Bulk Domain Availability Check

## When to Use

- User asks to "check what 4-letter .com domains are available"
- User wants to find short/patterned domains (AABB, ABAB, AAAB, ABBB) for a project
- User asks to search across multiple TLDs (.com, .net, .cc, .io, etc.)
- You need to batch-check hundreds to thousands of domains for availability

## Core Technique: Raw Socket WHOIS

The Python `whois` library often fails in containerized/VPS environments due to IANA socket issues (connection reset by peer, DNS resolution failures). **Use raw sockets instead** — direct TCP connection to the TLD's authoritative whois server on port 43.

### .com and .net (Verisign)

```python
import socket

def whois_lookup(domain):
    """Query whois.verisign-grs.com for .com/.net domains. Returns True if available."""
    server = "whois.verisign-grs.com"
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(8)
    try:
        sock.connect((server, 43))
        sock.send(f"{domain}\r\n".encode())
        response = b""
        while True:
            data = sock.recv(4096)
            if not data:
                break
            response += data
        sock.close()
        text = response.decode("utf-8", errors="replace")
        # Verisign returns "No match for" when domain is available
        return "No match for" in text
    except Exception:
        return None  # Error / transient
```

### Other TLDs

Each TLD has its own whois server. Common ones:

| TLD | Whois Server |
|-----|-------------|
| .com | whois.verisign-grs.com |
| .net | whois.verisign-grs.com |
| .org | whois.publicinterestregistry.org |
| .io | whois.nic.io |
| .cc | whois.nic.cc |
| .xyz | whois.nic.xyz |
| .me | whois.nic.me |
| .top | whois.nic.top |
| .vip | whois.nic.vip |

## Pattern Generation

### 4-Letter Patterns (26² = 676 combinations each)

```python
import string
letters = string.ascii_lowercase

def gen_pattern(pattern_desc, tld="com"):
    """Generate domains for a pattern. pattern_desc e.g. 'AABB', 'ABAB', 'AAAB', 'ABBB'"""
    domains = []
    for a in letters:
        for b in letters:
            if a == b:
                continue  # skip same-letter (already covered by other patterns)
            if pattern_desc == "AABB":
                d = f"{a}{a}{b}{b}"
            elif pattern_desc == "ABAB":
                d = f"{a}{b}{a}{b}"
            elif pattern_desc == "AAAB":
                d = f"{a}{a}{a}{b}"
            elif pattern_desc == "ABBB":
                d = f"{a}{b}{b}{b}"
            else:
                continue
            domains.append(f"{d}.{tld}")
    return domains
```

**Available counts for .net** (from real scan — these are the pools of actually-checked availability):

| Pattern | Count | Notes |
|---------|-------|-------|
| AABB .net | 0 | All taken |
| ABAB .net | ~12 | e.g. `whwh.net`, `rfrf.net`, `ejej.net` |
| AAAB .net | ~100 | e.g. `eeeb.net`, `jjja.net`, `wwwf.net` |
| ABBB .net | ~75 | e.g. `uaaa.net`, `rwww.net`, `jbbb.net` |

### wf-Branded Domains (2-letter prefix + numbers/letters)

When the user's brand is "wf" (e.g., from "wufeng"), additional patterns to check:

```
# wf + 2 digits (wf00.net - wf99.net) — many available
# wf + 1 digit + 1 letter (wf1a.net - wf9z.net) — many available
# 1 digit + wf + 1 digit (w0f0.net - w9f9.net) — many available
```

## Batch Checking

### Parallel Execution

```python
import concurrent.futures

domains = [...]  # your generated list
available = []

with concurrent.futures.ThreadPoolExecutor(max_workers=16) as executor:
    futures = {executor.submit(whois_lookup, d): d for d in domains}
    for future in concurrent.futures.as_completed(futures):
        domain = futures[future]
        try:
            result = future.result()
        except Exception:
            result = None
        
        if result is True:
            available.append(domain)
        elif result is None:
            errors.append(domain)
```

- **max_workers=16** works well — whois servers usually rate-limit per connection, not per IP, so more concurrency doesn't help much
- **Set timeout** on the socket to 8 seconds (some domains hang)
- **Rate-limiting**: Verisign allows ~50 queries/second from one IP before rate-limiting. 16 workers is safe.

### Organization by Pattern

Track which pattern each domain belongs to for clean reporting:

```python
domain_to_pattern[domain] = pattern  # "AABB", "ABAB", etc.
```

Then present results grouped by pattern, with counts.

## When Premium 4-Letter .com is Exhausted

All 4-letter .com domains (456,976 combinations, any pattern) have been registered for years. When they're all taken:

1. **Switch to .net** — ~187 available in patterned 4-letter (mostly AAAB and ABBB)
2. **Add numbers** — letter+digit combos (wf01.net, aa11.com) have many available
3. **Try 5-letter patterns** — AABBC, ABABC, etc. (much larger pool)
4. **Meaningful words** — relay, proxy, gate, hub, flow, etc. as short 5-6 letter .net
5. **Use the user's brand + suffix** — e.g. wfapi.net, apiwf.net, wfflow.net, wfnode.net (many available!)

## API Relay Domain Suggestions

For an API relay/proxy business, recommendable .net domains (verified available as of mid-2026):

| Domain | Type | Reasoning |
|--------|------|-----------|
| `wfapi.net` | Brand+API | "WF API", instantly recognizable |
| `apiwf.net` | API+Brand | Same meaning, different order |
| `wfyun.net` | Brand+Cloud | "WF Yun" (云) |
| `wfflow.net` | Brand+Flow | Flow/throughput, good for relay |
| `wfnode.net` | Brand+Node | Node in the network |
| `relayx.net` | Relay+X | Direct meaning: relay station |
| `apixy.net` | API+XY | Short, API-focused |
| `proxyu.net` | Proxy+U | Proxy/U |
| `liufy.net` | 流FY | Chinese "flow" + FY |

## Relationship to domain-checking

⚠️ This skill overlaps significantly with `devops/domain-checking`. Both cover the same raw-socket WHOIS technique, same domain patterns, same batch-checking approach, and same pitfalls. The `devops/domain-checking` skill is the more comprehensive and actively-maintained version. Consolidation via the background curator is recommended.

## Common Pitfalls

1. **`!` in passwords breaks bash heredoc/echo**: When setting admin passwords in .env files via SSH, avoid `!` (exclamation mark) — bash interprets it as history expansion. Use only alphanumeric (`openssl rand -hex 16`).
2. **python-whois library unreliable in containers**: The `pip install python-whois` library often fails with IANA socket errors in Docker/container environments. Always fall back to raw socket approach.
3. **Rate limiting**: If you get mostly `None` results (timeouts), you're being rate-limited. Reduce concurrency to 4-8 workers or add a small delay.
4. **TLD-specific whois servers**: Not all TLDs use Verisign. Test the whois server for a known-registered domain first to confirm the server is correct.
