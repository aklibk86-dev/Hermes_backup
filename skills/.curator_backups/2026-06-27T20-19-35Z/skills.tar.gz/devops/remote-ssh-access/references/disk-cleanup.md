# Docker + System Disk Cleanup on Remote VPS

## Overview

After a session of memory diagnostics or Docker management, the VPS often accumulates unused Docker images, dangling layers, system caches, and old log files. This reference covers the full cleanup workflow.

## Step 1: Assess Current Disk Usage

```bash
df -h /
# 50G total, X used, Y avail, Z% used
```

## Step 2: Identify Space Hogs

### Largest directories at root:

```bash
du -sh /* 2>/dev/null | sort -rh | head -20
```

Usually `/var/lib` (Docker data) is the largest consumer.

### Docker system overview:

```bash
docker system df
# Shows: Images, Containers, Local Volumes, Build Cache
# Look at RECLAIMABLE column — that's your target
```

### Individual Docker image sizes:

```bash
docker images --format '{{.Repository}}:{{.Tag}}\t{{.Size}}' | sort -k2 -rh
```

### Find unused images (containers killed but images still present):

```bash
used_images=$(docker ps -a --format '{{.Image}}' | sort -u)
docker images --format '{{.Repository}}:{{.Tag}} {{.Size}}' | while read line; do
  repo=$(echo "$line" | awk '{print $1}')
  size=$(echo "$line" | awk '{print $3}')
  if ! echo "$used_images" | grep -q "$repo"; then
    echo "$repo  $size  (unused)"
  fi
done
```

## Step 3: Clean Up

### Remove all unused Docker images:

```bash
docker image prune -a -f
```

This removes:
- Images no longer referenced by any container (running or stopped)
- Dangling images (untagged layers)
- Does NOT affect running containers

### Remove Docker build cache:

```bash
docker builder prune -a -f
```

### Remove unused networks, stopped containers, dangling volumes:

```bash
docker system prune -f
```

### Clean system caches:

```bash
# apt package cache
apt-get clean

# Systemd journal (keep only 200MB)
journalctl --vacuum-size=200M

# Remove temp files older than 1 day
find /tmp -type f -atime +1 -delete 2>/dev/null
find /tmp -type d -empty -delete 2>/dev/null

# Remove archived logs older than 30 days
find /var/log -type f -name '*.log.*' -mtime +30 -delete 2>/dev/null
```

## Step 4: Verify Results

```bash
df -h /
docker system df
```

Expected outcome on a 50G disk: ~30G used → ~21G used, freeing 9+ GB.

## Typical Space Hogs Found in Practice

| Image / Data | Typical Size | Note |
|---|---|---|
| maxkb (AI app) | 4.6 GB | Large model/runtime image |
| hermes-agent | 4.6 GB | Core agent — keep if in use |
| uptime-kuma | 2.5 GB | Keep most recent tag |
| n8n | 2.5 GB | Remove if container stopped |
| cloudreve | 1.9 GB | Keep if running |
| openresty | 1.4 GB | Keep — reverse proxy |
| mysql:5.7 | 700 MB | Often unused older version |
| postgres variants | 400-600 MB each | Keep active versions only |
| Old tags (`:latest` when `:version` is the active one) | varies | These accumulate over time |

## Pattern: Send All Commands in a Single SSH Session

```python
# Using execute_code + paramiko (the paramiko import works because
# execute_code runs inside the uv venv where paramiko is installed)
import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(host, port, username, password, timeout=10)

# Step 1: docker image prune
stdin, stdout, stderr = ssh.exec_command("docker image prune -a -f")
print(stdout.read().decode())

# Step 2: system cleanups
for cmd in [
    "docker builder prune -a -f 2>&1",
    "docker system prune -f 2>&1",
    "apt-get clean 2>&1",
    "journalctl --vacuum-size=200M 2>&1",
    "find /tmp -type f -atime +1 -delete; find /tmp -type d -empty -delete 2>/dev/null",
    "find /var/log -type f -name '*.log.*' -mtime +30 -delete 2>/dev/null",
]:
    stdin, stdout, stderr = ssh.exec_command(cmd)
    output = stdout.read().decode().strip()
    if output:
        print(cmd[:50] + ":", output[:200])

# Step 3: verify
stdin, stdout, stderr = ssh.exec_command("df -h /")
print(stdout.read().decode())

ssh.close()
```

## Pitfalls

- **apt clean vs apt autoremove**: `apt-get clean` only removes cached .deb packages. Use `autoremove` to remove unused dependencies (but be careful — it may remove things 1Panel needs).
- **journalctl vacuum**: Only works if journal is persisted (not volatile). Check `du -sh /var/log/journal` first.
- **Docker image prune -a**: Removes ALL images not used by running containers. If you have a stopped container that you plan to restart, its image will be removed. Use `docker container rm <name>` first if you're sure, then prune.
- **Stopped containers keep data**: `docker image prune -a` does NOT remove volumes. To clean unused volumes: `docker volume prune` (but verify data isn't needed first).
- **THP disable doesn't free disk space**: It frees RAM, not disk. Don't confuse the two — check `df -h` for disk, `free -h` for RAM.
