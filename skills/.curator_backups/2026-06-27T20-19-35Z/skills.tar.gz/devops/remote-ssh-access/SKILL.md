---
name: remote-ssh-access
description: "Use when you need to SSH into a remote Linux server from within Hermes — especially when sshpass, pexpect, or paramiko are unavailable. Covers password-based auth via SSH_ASKPASS, SCP file transfer, command execution, and troubleshooting headless SSH connections."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [devops, ssh, remote-access, server, password-auth, scp]
    related_skills: [1panel]
---

# Remote SSH Access

## SSH via Paramiko from execute_code (Inside-Container Pattern)

When Hermes runs inside a container (no direct Docker socket, no sshpass), use `execute_code` with `paramiko`:

```python
from hermes_tools import terminal
import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('host', port=22, username='root', password='password', timeout=10)

# Run command
stdin, stdout, stderr = ssh.exec_command('command')
output = stdout.read().decode()
error = stderr.read().decode()

ssh.close()
```

### Base64 Encoding to Avoid Shell Escaping

When passing complex Python scripts through SSH, shell escaping becomes unmanageable. Use base64:

```python
import base64

script = '''#!/usr/bin/env python3
... python code with quotes, \\n, special chars ...
'''

b64 = base64.b64encode(script.encode()).decode()
stdin, stdout, stderr = ssh.exec_command(
    f"echo '{b64}' | base64 -d > /tmp/script.py && python3 /tmp/script.py"
)
```

This avoids all heredoc/quote-escaping issues with nested quotes, backslashes, and special characters.

### Pitfalls

- **Container has no Docker socket**: `docker ps` inside the container fails. SSH to the host is the workaround.
- **shhpass not installed**: Don't try to install it (often no root in container). Use paramiko instead.
- **Environment isolation**: The container's python/uv may have paramiko installed even when the host doesn't have python3. Check `uv pip list | grep paramiko`.
- **Cookies/file handles**: When using remote APIs, write temp files on the remote host (not the local container), or use mktemp inside SSH sessions.
- **Token masking**: Writing `***` in source code writes literal asterisks to config files. Build tokens from parts: `bot_id + ':' + bot_secret` to keep the real value.

## Related References

| File | When to Load |
|------|-------------|
| `references/telegram-monitor-api.md` | Managing TelegramMonitor keyword rules, bot config, message queries via API |
| `references/vps-cron-scheduling.md` | Deploying and scheduling Python cron jobs on remote VPS | (Headless Password Auth)

## Overview

Hermes often needs to SSH into remote servers. When the Hermes host lacks `sshpass`, `pexpect`, or `paramiko`, the standard approach (`ssh user@host` + password prompt) fails because there's no terminal to read the password from.

The **SSH_ASKPASS + setsid** pattern solves this by telling SSH to ask a script for the password instead of reading from `/dev/tty`.

## When to Use

- You need to SSH into a remote server with password authentication
- `sshpass` is not installed and you can't install it (no root/sudo)
- `pexpect` / `paramiko` Python libraries are unavailable
- You need to SCP files to/from a remote server with the same pattern
- The error `read_passphrase: can't open /dev/tty: No such device or address` appears

## Prerequisites

- `openssh-client` (always present on Linux)
- `setsid` (part of `util-linux`, always present)
- The remote server's IP, port, username, and password

## Core Pattern

### 1. Create the password-providing script

```bash
cat > /tmp/askpass.sh << 'SCRIPT'
#!/bin/sh
echo "THE_SSH_PASSWORD"
SCRIPT
chmod +x /tmp/askpass.sh
```

**Security note**: The password is stored in plaintext on disk. Use only in trusted environments. Clean up with `rm /tmp/askpass.sh` after the session.

### 2. SSH into the server

```bash
SSH_ASKPASS=/tmp/askpass.sh DISPLAY=none:0 setsid -w ssh \
  -o StrictHostKeyChecking=no \
  -o UserKnownHostsFile=/dev/null \
  -p PORT root@HOST_IP 'command'
```

Key flags explained:
| Flag | Purpose |
|------|---------|
| `SSH_ASKPASS=/tmp/askpass.sh` | Tells SSH how to get the password |
| `DISPLAY=none:0` | Prevents SSH from trying an X11 prompt |
| `setsid -w` | Creates a new session so SSH doesn't try /dev/tty |
| `-o StrictHostKeyChecking=no` | Skips host key confirmation (first connection) |
| `-o UserKnownHostsFile=/dev/null` | Don't save host keys (avoids duplicates) |

**Without `setsid -w`**: SSH detects a controlling terminal and tries `/dev/tty` for the password prompt, which fails with `read_passphrase: can't open /dev/tty`.

### 🔄 SSH_ASKPASS Lifecycle

Create the askpass script once at the start of a session, reuse it across all SSH/SCP calls, and **do NOT delete it until the session is done** — you may need to SSH again later. Recreating it wastes time and risks typo errors.

```bash
# ONE-TIME setup (do this first)
cat > /tmp/askpass.sh << 'SCRIPT'
#!/bin/sh
echo "THE_SSH_PASSWORD"
SCRIPT
chmod +x /tmp/askpass.sh

# ... many SSH calls ...

# Only clean up when the session is truly done
rm -f /tmp/askpass.sh
```

### 3. SCP files (same pattern)

```bash
SSH_ASKPASS=/tmp/askpass.sh DISPLAY=none:0 setsid -w scp \
  -o StrictHostKeyChecking=no \
  -o UserKnownHostsFile=/dev/null \
  -P PORT \
  /local/file root@HOST_IP:/remote/path
```

Note: SCP uses `-P` (uppercase) for port, unlike SSH which uses `-p` (lowercase).

### 4. Run longer commands or scripts

```bash
# Single multi-line command
SSH_ASKPASS=/tmp/askpass.sh DISPLAY=none:0 setsid -w ssh \
  -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
  -p PORT root@HOST_IP '
  docker ps --format "table {{.Names}}\t{{.Status}}"
  echo "---"
  free -h
'

# Copy a Python script and execute it
SSH_ASKPASS=/tmp/askpass.sh DISPLAY=none:0 setsid -w scp \
  -P PORT /tmp/my_script.py root@HOST_IP:/tmp/my_script.py

SSH_ASKPASS=/tmp/askpass.sh DISPLAY=none:0 setsid -w ssh \
  -p PORT root@HOST_IP 'python3 /tmp/my_script.py'
```

## Troubleshooting

### `Permission denied (password).`
- Password is wrong — double-check the credentials
- Remote server may have disabled password auth — check `/etc/ssh/sshd_config` for `PasswordAuthentication yes`

### `ssh: connect to host PORT: Connection refused`
- Port is wrong or SSH service isn't running — verify with `timeout 5 bash -c 'echo >/dev/tcp/IP/PORT'`

### `read_passphrase: can't open /dev/tty`
- Missing `setsid -w` — SSH tries the controlling terminal instead of SSH_ASKPASS

### SCP returns empty or no output
- SCP outputs nothing on success by default. Check exit code or add verbose: `scp -v ...`
- Ensure `-P PORT` (uppercase) is used for SCP port, not `-p`

### `Host key verification failed`
- Add `-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null` to skip host key check

## Alternative A: Python pexpect (via uv)

When `SSH_ASKPASS` + `setsid` fails (e.g. the Hermes environment has no `DISPLAY` / `setsid` quirks), use Python's `pexpect` module as a fallback:

> **Note**: There's also paramiko (Alternative B below), which avoids pexpect's shell-prompt-matching pitfalls entirely for command-execution-only use cases.

### Setup (one-time)

```bash
uv pip install pexpect   # or: pip install pexpect
```

### SSH with pexpect

```python
import pexpect

child = pexpect.spawn('ssh -o StrictHostKeyChecking=no -p PORT root@HOST_IP command', 
                      encoding='utf-8', timeout=20)
child.expect('password:')
child.sendline('THE_PASSWORD')
child.expect(pexpect.EOF, timeout=10)
print(child.before)
```

### SCP with pexpect

```python
child = pexpect.spawn('scp -o StrictHostKeyChecking=no -P PORT /local/path root@HOST_IP:/remote/path',
                      encoding='utf-8', timeout=30)
child.expect('password:')
child.sendline('THE_PASSWORD')
child.expect(pexpect.EOF, timeout=20)
print(child.before)
```

### Multi-step: interactive login + multiple commands

If you need to run several commands in one SSH session:

```python
child = pexpect.spawn('ssh -o StrictHostKeyChecking=no -p PORT root@HOST_IP', 
                      encoding='utf-8', timeout=20)
child.expect('password:')
child.sendline('THE_PASSWORD')
# Wait for shell prompt
child.expect('#')  # or '$' depending on shell
# Run commands
child.sendline('docker ps')
child.expect('#')
child.sendline('free -h')
child.expect('#')
print(child.before)
```

**⚠️ The shell-prompt matching pitfall**: `expect('#')` can false-match on at least two things:
1. **MOTD content** — The SSH banner/MOTD may contain `#` in comments or ASCII art
2. **Terminal escape codes** — Some shells send `\x1b[?2004h` (bracketed paste mode) before the prompt, and the `#` from the prompt appears in the middle of ANSI escape sequences. `expect(r'#$')` fails because the escape sequences consume the `#` into the buffer before the regex runs.

**Solutions** (use in this preference order):

1. **Pass the command on the SSH invocation** — Avoid interactive mode entirely (MOST reliable):
   ```python
   child = pexpect.spawn('ssh ... root@HOST "docker exec ..."')
   child.expect('password:')
   child.sendline('PASS')
   child.expect(pexpect.EOF, timeout=10)
   ```

2. **Use `read_nonblocking()` after `time.sleep()`** — Instead of `expect('#')`, send commands, wait, and collect:
   ```python
   child.sendline('my-command')
   child.sendline('echo "===DONE==="')
   time.sleep(3)  # give SSH time to execute and send output
   try:
       data = child.read_nonblocking(size=8000, timeout=5)
   except:
       data = child.before
   # Extract command output: data[data.find('my-command'):data.find('===DONE===')]
   ```
   Key: `child.before` with `encoding='utf-8'` is already a string, not bytes — no `.decode()` needed.

3. **Send command before the prompt check** — Send the command immediately after the password, then wait:
   ```python
   child.sendline('ecwoVMLX4252')   # password
   child.sendline('command')         # sent before prompt check
   child.expect('#', timeout=10)     # matches prompt AFTER command runs
   ```

4. **Use a unique marker** — Wrap output in echo markers:
   ```python
   child.sendline('echo "===START===" && my-command && echo "===END==="')
   child.expect('===END===', timeout=10)
   ```

### Chaining: SCP a SQL file, then SSH to execute it

```python
# 1. SCP the file
child = pexpect.spawn('scp ...', encoding='utf-8', timeout=30)
child.expect('password:'); child.sendline('PASS')
child.expect(pexpect.EOF)

# 2. Execute via SSH
child2 = pexpect.spawn('ssh ...', encoding='utf-8', timeout=30)
child2.expect('password:'); child2.sendline('PASS')
child2.expect(pexpect.EOF, timeout=20)
```

**Important**: Each `pexpect.spawn` call is a new SSH connection — you must re-enter the password each time. For multiple commands, use the interactive shell approach above.

### When to use pexpect vs SSH_ASKPASS

| Scenario | Approach |
|----------|----------|
| Hermes has `setsid` + `DISPLAY=:0` works | SSH_ASKPASS (simpler) |
| `setsid` missing or DISPLAY trick fails | pexpect (reliable fallback) |
| You need to wait for a specific prompt/pattern | pexpect (GREAT for this — it can `.expect()` custom patterns) |
| Single command, no interactive interaction | Either approach works |

## Alternative B: Python paramiko (Recommended for Programmatic SSH)

When the Hermes environment lacks a local Docker daemon but you need to run commands on a remote VPS that has Docker, paramiko provides a clean programmatic SSH interface — no temporary files, no `setsid` tricks, no shell-prompt matching.

### Setup

```bash
uv pip install paramiko
```

Paramiko installs into the uv-managed venv at `/opt/hermes/.venv/`. Scripts using paramiko must be run with `/opt/hermes/.venv/bin/python3`, not bare `python3`.

### Basic Pattern: Write Script, Run with UV Python

The cleanest workflow is:

1. Write a Python script to `/tmp/` that uses paramiko
2. Execute it with `/opt/hermes/.venv/bin/python3 /tmp/script.py`

### Core Usage

```python
import paramiko

host = '149.104.8.237'
port = 37926
username = 'root'
password = 'ecwoVMLX4252'

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(host, port=port, username=username, password=password, timeout=30)

# Run a single command
stdin, stdout, stderr = ssh.exec_command('docker ps --format "{{.Names}}"', timeout=30)
exit_status = stdout.channel.recv_exit_status()
print(stdout.read().decode().strip())
print(stderr.read().decode().strip())

ssh.close()
```

### Writing Files to Remote Server

Use `stdin.write()` + `stdin.channel.shutdown_write()` to pipe content into a remote command:

```python
content = '''server {
    listen 80;
    server_name example.com;
    location / {
        proxy_pass http://127.0.0.1:3000;
    }
}
'''

stdin, stdout, stderr = ssh.exec_command(
    'cat > /opt/1panel/apps/openresty/openresty/conf/default/uptime.conf',
    timeout=10
)
stdin.write(content)
stdin.channel.shutdown_write()
exit_status = stdout.channel.recv_exit_status()
print('Write RC:', exit_status)
```

This avoids all heredoc/shell-escaping problems with `$`, backticks, etc.

### Practical Deploy Workflow (Docker + Nginx on Remote VPS)

```python
ssh = paramiko.SSHClient()
ssh.connect(host, port=port, username=username, password=password, timeout=30)

# 1. Pull and run container (bind to 127.0.0.1 only)
cmd = (
    'docker pull louislam/uptime-kuma:latest && '
    'docker rm -f uptime-kuma 2>/dev/null; '
    'docker run -d --name uptime-kuma --restart unless-stopped '
    '-p 127.0.0.1:3003:3001 -v uptime-kuma-data:/app/data '
    'louislam/uptime-kuma:latest'
)
stdin, stdout, stderr = ssh.exec_command(cmd, timeout=300)
print(stdout.read().decode().strip())

# 2. Write Nginx config
config = '''server {
    listen 80;
    server_name uptime.aklibk.com;
    location / {
        proxy_pass http://127.0.0.1:3003;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}'''
stdin, stdout, stderr = ssh.exec_command(
    'cat > /opt/1panel/apps/openresty/openresty/conf/default/uptime.conf',
    timeout=10
)
stdin.write(config)
stdin.channel.shutdown_write()

# 3. Reload Nginx
stdin, stdout, stderr = ssh.exec_command(
    'docker exec 1Panel-openresty-qMxV nginx -t && '
    'docker exec 1Panel-openresty-qMxV nginx -s reload',
    timeout=10
)

ssh.close()
```

### When to Use paramiko vs Other Approaches

| Scenario | Approach |
|----------|----------|
| Single SSH command, no Python post-processing | SSH_ASKPASS + setsid |
| Multi-command interactive session | pxssh (pexpect-based) |
| **Need to run commands AND process output programmatically** | **paramiko (best)** |
| Need to write files to remote AND execute | paramiko (cleanest — no heredoc escaping) |
| Running in a container without setsid/sshpass | paramiko or pxssh |
| Hermes execution environment has no Docker socket, VPS does | **paramiko (ideal — deploy remotely)** |
| Writing multi-step scripts that process and compare outputs between steps | paramiko (cleanest — no shell escaping issues) |

### Practical Workflow: Write Script, Execute with UV Python

When paramiko is installed via `uv pip install paramiko`, scripts must be executed with the uv-managed Python binary. The reliable pattern is:

1. **Install paramiko** (one-time per env):
   ```bash
   uv pip install paramiko
   ```

2. **Write a Python script** to `/tmp/` using `write_file`:
   ```python
   import paramiko
   # ... your SSH logic ...
   ```

3. **Execute with uv Python**:
   ```bash
   /opt/hermes/.venv/bin/python3 /tmp/my_script.py
   ```

⚠️ **IMPORTANT**: Bare `python3 /tmp/script.py` will NOT find paramiko — it uses the system Python at `/usr/bin/python3`, not the uv-managed venv. Always use the absolute path `/opt/hermes/.venv/bin/python3`.

For quick one-off commands, you can inline them via `python3 -c` but only if run within the uv venv context. The `/opt/hermes/.venv/bin/python3` path is the safest bet.

### 🚀 Shortcut: execute_code + paramiko (No Script File Needed)

When paramiko is already installed in the uv venv, you can skip writing a separate script file and use `execute_code` directly. The `execute_code` tool runs inside the uv venv automatically, so `import paramiko` works without any path gymnastics.

**Pattern:**

```python
from hermes_tools import terminal  # only if you also need shell commands
import paramiko

host = "149.104.8.237"
port = 37926
username = "root"
password = "YOUR_PASSWORD"

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(host, port=port, username=username, password=password, timeout=10)

# Run commands
stdin, stdout, stderr = ssh.exec_command("docker ps --format '{{.Names}}'")
output = stdout.read().decode()
print(output)

# Write files via stdin
stdin, stdout, stderr = ssh.exec_command("cat > /remote/path/file.conf")
stdin.write("content with $dollar_signs and `backticks` that won't get mangled by shell")
stdin.channel.shutdown_write()

ssh.close()
```

**Benefits over the script-file approach:**
- No `/tmp/` file to create, run, and clean up
- The `from hermes_tools import terminal` import is harmless but available if needed
- Output appears in the execute_code stdout immediately
- All Python stdlib available for processing (JSON parsing, loops, conditionals)

**When NOT to use execute_code:**
- Task will take more than 5 minutes (execute_code timeout limit)
- You need to process outputs larger than 50KB
- You need to call `delegate_task` or other advanced Hermes tools inside the loop (execute_code cannot call `clarify`/`memory`/`send_message`/`delegate_task`)

### Key Differences from SSH_ASKPASS

No `setsid` setup required — just install paramiko once via `uv pip install paramiko` and write Python scripts. No temporary password files to clean up. File writes avoid shell-escaping issues.

## Common Pitfalls

1. **Forgetting `setsid -w`** — This is the most common mistake. Without it, SSH_ASKPASS is ignored.
2. **`SSH_ASKPASS` path not absolute** — Use an absolute path like `/tmp/askpass.sh`.
3. **Password script not executable** — Must `chmod +x /tmp/askpass.sh`.
4. **Shell quoting** — When passing commands with variables, use single quotes around the command to prevent local expansion: `ssh ... 'echo $HOSTNAME'` (not double quotes).
5. **SCP port flag** — `-P` for SCP, `-p` for SSH. Getting them reversed is a common error.
6. **File permissions on remote** — SCP preserves permissions by default. Use `-p` flag on scp if you need to preserve timestamps.
7. **Password exposed in shell history** — The password echo script stores it in plaintext. Consider cleaning up afterward.
8. **pexpect: `sshpass: command not found`** — You don't need `sshpass` for pexpect; pexpect drives the SSH prompt directly. Install pexpect with `uv pip install pexpect` if missing.
9. **pexpect: `ModuleNotFoundError: No module named 'pexpect'`** — Use `uv run python3` instead of bare `python3` so it picks up the uv-managed venv where pexpect was installed.
9. **Writing Nginx configs via heredoc: `$` variables get escaped** — When you write an Nginx config file via SSH heredoc (`cat > file << "EOF"`), the `$` signs in Nginx variables (`$host`, `$http_upgrade`, `$remote_addr`, etc.) must NOT be escaped — they should be literal `$` in the file. If you use `\$` to protect from shell expansion, the file will have `\$host` instead of `$host`, and Nginx will return 400 Bad Request. **Fix**: Use `sed -i 's/\\\$/$/g'` on the config file after creation, or write the config with Python instead of heredoc.

   **Correct pattern** — single-quoted heredoc (highest delimiter 'EOF' — no shell expansion, `$` stays literal):
   ```bash
   cat > /path/to/file.conf << 'EOF'
   proxy_set_header Host $host;
   proxy_set_header X-Real-IP $remote_addr;
   EOF
   ```
   
   **WRONG** — double-quoted heredoc with `\$` escaping creates `\$host` in the file:
   ```bash
   cat > file.conf << EOF
   proxy_set_header Host \$host;   # BROKEN: creates literal \$host
   EOF
   ```
   
   **Fix if already broken**:
   ```bash
   sed -i 's/\\\$/$/g' /path/to/file.conf
   ```
11. **pexpect interactive: `#`-prompt matches MOTD or escape codes, not command output** — The SSH MOTD/banner may contain `#` characters, or terminal escape sequences (like bracketed paste mode `\x1b[?2004h`) may consume the `#` before the regex engine runs. This causes `expect('#')` to match on the wrong content. Three workarounds in preference order: (a) pass the command on the SSH command line to avoid interactivity, (b) use `read_nonblocking()` after `time.sleep(3)` instead of `expect('#')`, (c) send the command before waiting for the prompt, then call `expect('#' )`, or (d) use echo markers like `echo "===MARKER==="` around the command and `expect('===MARKER===')`.

### pxssh: The Cleaner Interactive Alternative

`pexpect.pxssh` wraps raw pexpect with automatic shell-prompt handling — no manual `expect('#')`, no MOTD false matches, no bracketed-paste-mode nightmares. It is the **recommended approach** for multi-command SSH sessions.

#### Setup

```python
from pexpect import pxssh

s = pxssh.pxssh()
s.login('HOST_IP', 'root', 'PASSWORD', port=PORT)
```

**Key params**: `port=`, `auto_prompt_reset=False` (essential — prevents pxssh from confusing the shell prompt with output), `timeout=30` (default is 30s).

#### Run Commands

```python
s.sendline('command')
s.prompt(timeout=15)           # waits for shell prompt
output = s.before.decode()     # stdout of the command
```

`prompt()` matches the shell prompt (`$` or `#`), not arbitrary output text — no false matches, no MOTD contamination.

#### Full Lifecycle Pattern

```python
from pexpect import pxssh

s = pxssh.pxssh()
s.login('149.104.8.237', 'root', 'YOUR_PASSWORD', port=37926, auto_prompt_reset=False)

s.sendline("docker exec new-api-postgres psql -U newapi -d new-api -c 'SELECT version()'")
s.prompt(timeout=15)
print(s.before.decode())

s.sendline("docker ps --format '{{.Names}} {{.Status}}'")
s.prompt(timeout=15)
print(s.before.decode())

s.logout()
```

**Note**: `auto_prompt_reset=False` is required — it skips pxssh's prompt auto-detection which can fail on some shell configs. Without it, pxssh may raise `pxssh.ExceptionPxssh: could not synchronize with the remote host`.

#### When to Use pxssh vs SSH_ASKPASS vs Manual pexpect

| Scenario | Approach |
|----------|----------|
| Single command, no interaction | SSH_ASKPASS + setsid (simplest) |
| Need custom pattern matching | Manual pexpect (flexible `.expect()`) |
| **Multi-command interactive session** | **pxssh (cleanest — this session's pattern)** |
| `setsid` missing / DISPLAY trick fails | pexpect or pxssh |

## Python Environment Setup on Remote Server

When you SSH into a bare Debian server and need to install Python packages (e.g., a PyPI tool), start here.

### Check current state

```bash
python3 --version
pip3 --version 2>&1 | grep -q "not found" && echo "NO PIP"
python3 -m ensurepip 2>&1 | grep -q "No module" && echo "NO ENSUREPIP"
```

Fresh Debian 13 installs often have **no pip** and **no ensurepip** — both must come from apt.

### Install pip + venv

```bash
# Use noninteractive to avoid hanging on prompts
DEBIAN_FRONTEND=noninteractive apt-get install -y python3-pip python3.13-venv
```

**⚠️ Apt lock contention**: If another apt process is running (from a previous SSH session or automated update), you get:
```
E: Could not get lock /var/lib/dpkg/lock-frontend. It is held by process NNNN (apt-get)
```
Kill the process or wait for it to finish: `while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1; do sleep 2; done`

### Create virtual environment

```bash
# Use home dir, NOT /opt (may have permission issues)
python3 -m venv ~/my-env

# Verify pip works inside venv
~/my-env/bin/pip --version
```

**Permission pitfalls**:
- `/opt` may have `drwxr-xr-x` owned by root — creating a venv there fails with `Permission denied`
- Use `~/my-env` (user home) or `/tmp/my-env` instead

### Install packages

```bash
~/my-env/bin/pip install <package-name>==<version>
# Or for the current shell:
source ~/my-env/bin/activate && pip install <package>
```

### Common installs on remote servers

| Package | Notes |
|---------|-------|
| Any PyPI tool | Use venv — don't install system-wide on Debian 13+ (PEP 668) |
| `pexpect` | `~/my-env/bin/pip install pexpect` — needed for interactive SSH via Python |
| `oss2` | Alibaba Cloud OSS SDK |
| `pip list \| grep <pkg>` | Check if installed without activating venv |

### Full pattern (install + verify)

```bash
# Install system deps (one-time)
DEBIAN_FRONTEND=noninteractive apt-get install -y python3-pip python3.13-venv

# Create venv and install
python3 -m venv ~/my-env
~/my-env/bin/pip install my-package==1.0.0

# Verify
~/my-env/bin/pip show my-package
~/my-env/bin/python3 -c "import my_package; print(my_package.__file__)"
```

## Reference Files

- `references/docker-memory-management.md` — Diagnose high RAM on a Docker VPS, find kernel-level culprits (THP, inactive anon), apply container memory limits
- `references/disk-cleanup.md` — Remove unused Docker images, system caches, old logs to free disk (newly added)
- `references/session-examples.md` — Real command patterns used against a Debian VPS
- `references/telegrammonitor-setup.md` — Configure keywords, bot tokens, and notification targets for self-hosted TelegramMonitor (ghcr.io/riniba/telegrammonitor) via its REST API; covers credential discovery, auth, keyword CRUD, and bot setup

## Verification Checklist

- [ ] `/tmp/askpass.sh` exists and is executable (`chmod +x`)
- [ ] Command is prefixed with `SSH_ASKPASS=/tmp/askpass.sh DISPLAY=none:0 setsid -w`
- [ ] SSH port uses `-p P`, SCP port uses `-P P`
- [ ] Host key flags: `-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null`
- [ ] Connection test: `ssh ... 'hostname'` returns the remote hostname
