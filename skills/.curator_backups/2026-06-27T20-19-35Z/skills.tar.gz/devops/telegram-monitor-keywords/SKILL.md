---
name: telegram-monitor-keywords
description: "Use when managing TelegramMonitor keyword rules (monitor/exclude) on VPS, or setting up daily analysis cron. Covers API interactions via SSH + Paramiko."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [telegram, monitoring, keywords, vps, cron]
    related_skills: [1panel-docker-deploy]
---

# TelegramMonitor Keyword Management

## Overview

TelegramMonitor runs in a Docker container (`telegram-monitor`) on the VPS at 149.104.8.237. It monitors a Telegram account (8619133439191 @htpnv) for keyword-matched messages and sends notifications via bot @aklibkbot.

## Access

SSH via paramiko to root@149.104.8.237:37926. API at `http://127.0.0.1:5005`.
- Login: admin / tgmonitor2024
- Bot token: 8325012304:***
- Target chat: 8288196655
- Cookie jar: /tmp/tc

## API Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| POST | /api/auth/login | Get cookie (username/password) |
| GET | /api/keywords | List all rules |
| POST | /api/keywords | Add rule |
| PUT | /api/keywords | Update rule |
| DELETE | /api/keywords/{id} | Delete rule |
| GET | /api/bot/status | Check bot connection |
| POST | /api/bot/targets | Add notification target |
| GET | /api/messages?page=1&pageSize=N | Get captured messages |

## Keyword Rule Payload

```python
{
    "id": 0,               # 0=new, existing id=update
    "accountId": None,     # None=global, or account id
    "ruleName": "name",
    "keywordValue": "pattern",   # text or regex
    "matchMode": "Regex",        # "Regex"|"Contains"|"Exact"|"Fuzzy"
    "isMatchUser": False,
    "userValue": None,
    "keywordAction": "Monitor",  # "Monitor"|"Exclude"
    "isCaseSensitive": False,
    "isEnabled": True,
    "priority": 20,              # higher = higher priority
    "remark": "备注"
}
```

## Rule Strategy

### Core Principle: Customer Intent vs Supplier Noise

The single most important lesson from real-world tuning: **single keywords catch noise, intent patterns catch customers**.

| Catching | Pattern type | Example | Outcome |
|----------|-------------|---------|---------|
| Suppliers/Ads | Product+price | "机场","VPN","API","U" | Catches ads, price lists, spam |
| Customers | Intent+need | "坏了","求推荐","想买","连不上" | Catches real requests |

**Iterative approach (learned from 3 rounds of refinement):**

1. **Round 1 — Broad keywords (FAIL)**: Single words like "机场","节点","VPN","代付". Result: 200 hits/day, 0 real customers. Catches airport channels, porn groups, gambling ads.
2. **Round 2 — Question patterns (BETTER)**: "谁会","有没有","求". Better but still catches suppliers who use these words.
3. **Round 3 — Intent-only + Ad-exclude (WINNING)**: Two-layer filter:
   - **Exclude layer** (priority 30): Ad patterns (价格表, 套餐, U/天, Gbps, 欢迎咨询, 联系购买, DDoS, 诚招代理)
   - **Monitor layer** (priority 20): Only demand-side patterns (坏了, 连不上, 求推荐, 想买, 收key, 需要代付)

### Priority System

- **Exclude rules**: priority 30 — evaluated first, messages matching any exclude rule are silently dropped
- **Monitor rules**: priority 20 — only messages that pass all exclude rules are checked against monitor patterns
- Higher number = evaluated first

### Rule Writing Guidelines

1. **Never use standalone single words** — "机场" catches airport chat groups, "节点" catches tech talk, "VPN" catches casino ads
2. **Always combine intent + product** — "求推荐+机场" not "机场" alone
3. **Exclude supplier language** — Price tables, packages, contact-info patterns are always ads
4. **Specificity wins** — "梯子用不了" is worth more than 10 vague terms
5. **Test against real data** — Run `curl -s -b /tmp/tc http://127.0.0.1:5005/api/messages?page=1&pageSize=20` to see what's being caught

### Known Noise Patterns (Auto-Exclude)

These should always be included in exclusion rules:
- **Porn/adult**: a片, 色情, av, porn, 裸聊, 约炮, 主播资源,
- **Gambling**: 博彩, 赌, 六合, 跑分, BC料, 平特一肖
- **Scam/shady**: 灰产, 暗网, 假钞, 接码, 网赚, 日赚
- **Movie/resource sharing**: 短剧, 电影, 影视, 阿里云盘
- **Ad language**: 价格表, 套餐, 起售, 欢迎咨询, 联系购买, U/天, Gbps, 无视通报, 高防
- **Supplier self-intro**: 老玩家, 从业多年, 诚招代理, 一手货源

## Daily Cron Job

Script: `/opt/tg_daily.py` on VPS
Schedule: `0 9 * * *` (daily 9:00 UTC = 17:00 Beijing)
Function: Fetches 24h messages, sends report via bot, identifies noise groups
Log: `/var/log/tg_daily.log`

## Bot Token Configuration

The bot token lives in the container's `appsettings.json`. It is NOT accessible via the web API — you must edit the config file and restart.

### Procedure

1. **Read current config** on the VPS host, modify `Bot.Tokens` and `Bot.Enabled`, then write it back:

```python
import paramiko, json, base64

ssh = paramiko.SSHClient()
ssh.connect(host, port, username, password)

# Read from container
stdin, stdout, stderr = ssh.exec_command("docker exec telegram-monitor cat /app/appsettings.json")
config = json.loads(stdout.read().decode())

# Set bot token and enable
bot_id = "1234567890"         # numeric bot ID
bot_secret = "ABCdef123..."   # secret from BotFather
config['Bot']['Enabled'] = True
config['Bot']['Tokens'] = [f"{bot_id}:{bot_secret}"]

# Write via base64 to avoid shell escaping
encoded = base64.b64encode(json.dumps(config, indent=2).encode()).decode()
ssh.exec_command(f"echo '{encoded}' | base64 -d > /tmp/bt.json && docker cp /tmp/bt.json telegram-monitor:/app/appsettings.json")

# Restart
ssh.exec_command("docker restart telegram-monitor")
time.sleep(5)
```

2. **Verify** via the bot status API:
```bash
curl -s -b /tmp/tc http://127.0.0.1:5005/api/bot/status
# Expected: {"enabled":true,"botCount":1,"connectedCount":1,"botUsernames":["@yourbot"]}
```

### ⚠️ Token Masking Pitfall

When writing the token in code, ALWAYS build from parts:
```python
# ✅ CORRECT
bot_token = "8325012304:" + "AAGZLRFiPM1PcMLVzN2YYDRkr6DRoQNXPi8"

# ❌ WRONG — writes literal asterisks to the config file
bot_token = "8325012304:***"   # file has: "8325012304:***" (invalid!)
```

The `***` in conversation output is a display mask — never use it in executable code.

### Known Config

| Setting | Value |
|---------|-------|
| Admin UI | https://telegram.wf1.one |
| Username | admin |
| Password | tgmonitor2024 |
| Bot token | 8325012304:*** |
| Bot username | @aklibkbot |
| Notification target | 8288196655 (private chat @MTBTQ) |

## Match Mode Behavior

| Mode | Behavior | Example input | Example match |
|------|----------|---------------|---------------|
| `Contains` | Substring match | `"机场"` | Matches any message containing "机场" |
| `Exact` | Full string match | `"求机场"` | Only matches "求机场" alone |
| `Regex` | Regex match (OR by default) | `"坏了\|连不上"` | Matches if **ANY** pattern is found |
| `Fuzzy` | **ALL keywords must match** (AND) | `"机场?修复?节点"` | Message must contain ALL of: 机场 AND 修复 AND 节点 |

⚠️ **Fuzzy mode is often NOT what you want.** The `?` separator creates an AND condition (`^(?=.*A)(?=.*B)(?=.*C).*$`), meaning the message must contain EVERY keyword. To match ANY keyword, use `Regex` mode with `|` separator instead.

## User Preferences

This user has expressed clear preferences for TelegramMonitor management:

- **DO NOT send daily reports or unsolicited notifications.** The cron-based daily report was disabled after the user said "不要给我发这个". If monitoring insights are needed, provide them on request only, not on a schedule.
- **Focus on customer intent, not keyword density.** Rule tuning should prioritize question patterns (坏了/求/想买/连不上) over product mentions (机场/节点/VPN), which produce too many false positives from ads and noise groups.
- **Iterate in conversation, not via cron.** Present rule changes and ask for feedback before deploying. Do not auto-generate exclusion rules.

## Useful Commands

```bash
# Check bot status
curl -s -b /tmp/tc http://127.0.0.1:5005/api/bot/status

# List all rules
curl -s -b /tmp/tc http://127.0.0.1:5005/api/keywords

# Run daily report manually (only if user asks)
python3 /opt/tg_daily.py

# View container logs
docker logs telegram-monitor --tail 30

# Restart after config change
docker restart telegram-monitor

# Login (re-auth after restart)
curl -s -c /tmp/tc -X POST http://127.0.0.1:5005/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"tgmonitor2024"}'
```

## Pitfalls

1. **Bot token must be written correctly** — build from parts, never use `***` in source code.
2. **Fuzzy mode is AND, not OR** — `?` separator creates all-must-match regex. Use `Regex` mode with `|` for OR.
3. **Messages API shape**: response data is nested: `msgs.get("data", {}).get("items", [])`.
4. **Cron container may lack cron binary** — install with `apt-get install -y cron && systemctl enable --now cron`.
5. **Script on VPS runs python3, container does NOT have python3** — config edits must copy files in.
6. **Time zones matter** — cron runs in UTC (0 9 * * * = 09:00 UTC = 17:00 Beijing).
7. **Daily report includes historical data** — after changing rules, the report shows messages captured BEFORE the change. New rules only affect future messages.
8. **Old data doesn't get re-filtered** — messages already in the DB stay in the DB. Only new messages go through new rules.
9. **DO NOT setup unsolicited cron notifications** without explicit user approval — the user will complain.
10. **Shell quoting in curl** — use single quotes for JSON payloads to avoid shell expansion of variables like `$cookie`.
