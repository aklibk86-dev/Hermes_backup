---
name: halo-mcp-server
description: Integrate Halo 2.x blog with AI assistants via halo-mcp-server (MCP protocol). Covers installation, authentication, post management, and known PAT limitations.
category: software-development
---

# Halo MCP Server

Integrate [Halo 2.x](https://github.com/halo-dev/halo) blogs with AI assistants via the [halo-mcp-server](https://pypi.org/project/halo-mcp-server/) MCP server.

## Installation

```bash
# Create venv and install
python3 -m venv ~/halo-mcp-env
source ~/halo-mcp-env/bin/activate
pip install halo-mcp-server

# Create config directory
mkdir -p ~/halo-mcp-server
```

## Configuration

Create `~/halo-mcp-server/.env`:

```env
HALO_BASE_URL=https://your-blog.example.com
HALO_TOKEN=pat_your_personal_access_token
MCP_SERVER_NAME=halo-mcp-server
MCP_LOG_LEVEL=INFO
```

### Getting a Personal Access Token (PAT)

1. Visit `https://your-blog.example.com/console`
2. Log in as admin → Personal Access Tokens → Create
3. Copy the full token (it starts with `pat_`)

### Alternative: Password Authentication

If PAT is insufficient for some operations, configure username/password in `.env`:

```env
HALO_USERNAME=admin
HALO_PASSWORD=your_password
```

## MCP Server Tools

The server provides these tools (auto-discovered on initialize):

| Tool | Description |
|:----|:----|
| `list_my_posts` | List posts by current user |
| `get_post` | Get post details |
| `create_post` | Create a new post |
| `update_post` | Update post metadata |
| `publish_post` | Publish a draft |
| `unpublish_post` | Unpublish a published post |
| `delete_post` | Move to recycle bin (UC API) |
| `get_post_draft` | Get draft content/snapshot |
| `update_post_draft` | Update post content |
| `list_categories` / `create_category` | Category management |
| `list_tags` / `create_tag` | Tag management |
| `upload_attachment` / `upload_attachment_from_url` | File management |

## Starting the Server

```bash
cd ~/halo-mcp-server
source ~/halo-mcp-env/bin/activate
python3 -m halo_mcp_server
```

The server listens on **stdio** (MCP stdio transport). Connect via subprocess.

> **Important:** Always run from the `.env` directory so pydantic-settings picks up the config. If you pass env vars from the shell, the terminal may redact secret values — rely on the `.env` file instead.

## Known PAT Limitations

**Personal Access Tokens (PATs) in Halo 2.x have significant limitations.** This is the most important knowledge in this file.

### What PAT CAN do:

| Operation | API | Works? |
|:----------|:----|:------:|
| List all posts | Console API | ✅ |
| Create draft post | Console API | ✅ |
| Get content/UC API | UC API | ✅ |
| Recycle (soft-delete) | UC API | ⚠️ (returns 200, doesn't mark deleted) |
| **Hard delete** | Content API | ✅ |

### What PAT CANNOT do properly:

| Operation | Issue | Workaround |
|:----------|:------|:-----------|
| **Publish (make public)** | Post has no owner → never enters PUBLISHED phase | Set `owner: 'admin_username'` + add `content.halo.run/content-json` annotation in create request |
| **Update/Delete** via Console API | Returns 500 (null owner) | Use Content API directly (`/apis/content.halo.run/v1alpha1/posts/{name}`) |
| **Delete via MCP `delete_post`** | MCP uses UC API → returns "success" but post not actually deleted | Use Content API: `DELETE /apis/content.halo.run/v1alpha1/posts/{name}` |

## The Three Halo API Layers

Understanding the API layer hierarchy is critical:

| Layer | Endpoint Prefix | Used For | PAT Works? |
|:------|:----------------|:---------|:----------:|
| **Console API** | `/apis/api.console.halo.run/v1alpha1/` | Listing, creating, dashboard stats | ✅ List/Create ❌ Update/Delete |
| **UC API** (User Center) | `/apis/uc.api.content.halo.run/v1alpha1/` | Per-user operations, recycle | ✅ Get/Recycle ❌ Update |
| **Content API** (Core REST) | `/apis/content.halo.run/v1alpha1/` | Direct CRUD on resources | ✅ All operations |

### Stats Endpoint

Dashboard uses:
```
GET /apis/api.console.halo.run/v1alpha1/stats
→ {"posts": N, "comments": ..., "visits": ...}
```

This counts ALL posts including deleted/ghost posts. To exclude deleted:
```
GET .../posts?labelSelector=content.halo.run/deleted=false
```

### Proper Post Creation with PAT

To create a publicly visible published post via PAT:

```json
{
  "post": {
    "apiVersion": "content.halo.run/v1alpha1",
    "kind": "Post",
    "metadata": {
      "name": "unique-name",
      "annotations": {
        "content.halo.run/content-json": "{\"raw\":\"<h2>Title</h2><p>Content</p>\",\"content\":\"<h2>Title</h2><p>Content</p>\",\"rawType\":\"HTML\"}"
      }
    },
    "spec": {
      "title": "Post Title",
      "slug": "post-slug",
      "owner": "wufeng",
      "publish": false,
      "visible": "PUBLIC",
      "allowComment": true,
      "categories": [],
      "tags": ["tag1"],
      "excerpt": {"autoGenerate": true, "raw": ""}
    }
  },
  "content": {
    "raw": "<h2>Title</h2><p>Content</p>",
    "content": "<h2>Title</h2><p>Content</p>",
    "rawType": "HTML"
  }
}
```

Then publish via:
```
PUT /apis/api.console.halo.run/v1alpha1/posts/{name}/publish?async=false
```

### Permanent Deletion of Ghost Posts

Posts with empty owner (`owner: ""`) that were created by PAT but can't be updated via Console API:

1. **Add `deleted` label** via Content API PUT (include full spec from listing)
2. **OR hard delete** via Content API: `DELETE /apis/content.halo.run/v1alpha1/posts/{name}`

The Content API `DELETE` fully removes the post from the database, unlike the UC API recycle which only soft-deletes.

## Single Page Management (About Pages, Custom Pages)

Single pages (关于/About, privacy policies, etc.) use the same snapshot system as posts but via different API endpoints.

### Console API Endpoint

```python
# List all single pages (get full page data)
GET /apis/api.console.halo.run/v1alpha1/singlepages  # lowercase!
→ {"items": [{"page": {...}, "content": {...}}, ...], "total": 3}

# Get single page detail (content API, read-only)
GET /apis/content.halo.run/v1alpha1/singlepages/{name}
```

### Update Single Page Content (the `{page, content}` pattern)

The Console API `PUT` needs **both** a full `page` object and a `content` object:

```python
# 1. GET current full page data from console API
r = client.get(f"{base_url}/apis/api.console.halo.run/v1alpha1/singlepages")
page_data = None
for item in r.json().get("items", []):
    p = item.get("page", {})
    if p.get("metadata", {}).get("name") == target_name:
        page_data = p
        break

# 2. PUT with {page, content} structure
update_payload = {
    "page": page_data,   # MUST include full metadata + spec
    "content": {
        "raw": "<h1>HTML content here</h1>",
        "content": "<h1>HTML content here</h1>",
        "rawType": "HTML",
    }
}

r = client.put(
    f"{base_url}/apis/api.console.halo.run/v1alpha1/singlepages/{name}",
    headers=headers, json=update_payload
)
```

### Publish Single Page

```python
r = client.put(
    f"{base_url}/apis/api.console.halo.run/v1alpha1/singlepages/{name}/publish",
    headers=headers, params={"async": "false"}
)
```

### Verify Public Access

```python
r = client.get(f"{base_url}/about")
# Check page status via content API
r = client.get(f"{base_url}/apis/content.halo.run/v1alpha1/singlepages/{name}")
status = r.json().get("status", {})
assert status.get("phase") == "PUBLISHED"
assert status.get("inProgress") == False
```

## Rich Content Formatting (Blog Style)

This user prefers blog content with **colorful, visually rich HTML formatting**:

| Element | Pattern | Example |
|:--------|:--------|:--------|
| **Hero banner** | Full-width gradient with emoji, centered text | `background: linear-gradient(135deg, #667eea, #764ba2)` |
| **Quote block** | Colored left border + subtle background | `border-left: 4px solid #f59e0b; background: rgba(...)` |
| **Section cards** | Grid layout with rounded corners | `grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); border-radius: 12px` |
| **Color per section** | Each card gets a unique gradient tint | Purple/mint/orange/pink/blue |
| **Emoji headers** | Use emoji + bold text as section markers | `🛠️ 目前正在折腾` |
| **Divider** | Subtle colored `<hr>` | `border-top: 1px solid rgba(99, 102, 241, 0.2)` |
| **Preference** | HTML (not Markdown) for complex layouts | `rawType: "HTML"` |

Format template for a rich blog section:
```html
<div style="background: linear-gradient(135deg, ...); border-radius: 16px; padding: 2em; margin: 2em 0;">
  <h2>👋 Section Title</h2>
  <p>Content paragraph with <strong>bold text</strong>.</p>
</div>
```

## Crash Recovery

### Halo 2 Crashes After Deleting All Posts

If you delete every post including system-required resources (e.g., `core.halo.run/v1alpha1/Link` for Serenity theme), Halo returns **500 errors on every page**.

**Symptom:** Homepage, archives, and single pages all return HTTP 500 with:
```
detail: "Scheme not found for core.halo.run/v1alpha1/Link"
```

**Fix:** Simply restart the Halo Docker container:
```bash
docker restart halo
```

Halo's extension system re-registers all schemas on startup. No data loss.

## Debugging Common Issues

### Cloudflare 403 blocking Halo API calls

When calling Halo's REST API through Cloudflare from a script or CLI (not a browser), Cloudflare may return:

```
HTTP 403 error code: 1010
```

**Fix:** Add a browser-like `User-Agent` header to all requests:

```python
headers = {
    "Authorization": f"Bearer {token}",
    "User-Agent": "Mozilla/5.0 (compatible)  # Required! Cloudflare blocks curl/python UA
}
```

Without this header, all API calls return 403 even with a valid PAT.

### "认证失败" when token is correct

The terminal tool may have redacted the token value in env vars. Instead of passing via shell:

```python
# BAD: env var gets redacted by terminal
proc_env['HALO_TOKEN'] = token  # might be '***'

# GOOD: let server read from .env file
proc_env.pop('HALO_TOKEN', None)
# Run from ~/halo-mcp-server/ directory
```

### Post created but 404 on public URL

Check:
1. Does `post.spec.owner` have a value? (Required for public visibility)
2. Does `post.metadata.annotations["content.halo.run/content-json"]` exist?
3. Is `releaseSnapshot` set? (If empty, publishing failed silently)
4. Try `async=false` on publish
5. **Archive labels missing**: The post's metadata.labels should include `content.halo.run/archive-year`, `content.halo.run/archive-month`, and `content.halo.run/archive-day`. Without these, Halo cannot route the public URL.

   **IMPORTANT:** Even when using the **Console API `POST` to create a post with `publish: True`**, the full publishing workflow may NOT trigger. The spec shows `publish: True` but the label `content.halo.run/published` remains `"false"`. This means Halo's state machine hasn't processed the publish — permalink stays None, archive labels are never generated.

   **The console API's `/publish` endpoint also may not work** (tested on Halo 2.25.3 — returns 404 or times out). The reliable workaround is to bypass the publishing state machine entirely:

   **Complete Working Workflow (Verified on Halo 2.25.3):**

   ```python
   from datetime import datetime
   ```python
   # Step 1: Create draft via Console API (sets owner + contributor correctly)
   post_data = {
       "post": {
           "apiVersion": "content.halo.run/v1alpha1",
           "kind": "Post",
           "metadata": {
               "name": "my-post-slug",
               "annotations": {
                   "content.halo.run/content-json": "{\"raw\":\"<p>HTML</p>\",\"rendered\":\"<p>HTML</p>\"}"
               }
           },
           "spec": {
               "title": "My Post",
               "slug": "my-post-slug",
               "publish": False,  # created as draft
               "visible": "PUBLIC",
               "allowComment": True,
               "excerpt": {"autoGenerate": True, "raw": ""},
               "htmlContent": "<p>HTML</p>",
               "tags": ["tag1"]
           }
       },
       "owner": {"displayName": "空缺", "name": "wufeng", "avatar": ""}
   }
   POST /apis/api.console.halo.run/v1alpha1/posts

   # Step 2: Create Snapshot with full HTML content
   PUT /apis/content.halo.run/v1alpha1/snapshots/{uuid}
   # (see snapshot structure above)

   # Step 3: Fix labels + link snapshot + publish via Content API PUT
   now = datetime.now()
   post[\"spec\"][\"publish\"] = True
   post[\"spec\"][\"baseSnapshot\"] = snapshot_id
   post[\"spec\"][\"headSnapshot\"] = snapshot_id
   post[\"spec\"][\"releaseSnapshot\"] = snapshot_id  # CRITICAL for public access
   post[\"metadata\"][\"labels\"] = {
       \"content.halo.run/published\": \"true\",
       \"content.halo.run/deleted\": \"false\",
       \"content.halo.run/owner\": \"wufeng\",
       \"content.halo.run/visible\": \"PUBLIC\",
       \"content.halo.run/archive-year\": str(now.year),
       \"content.halo.run/archive-month\": f\"{now.month:02d}\",
       \"content.halo.run/archive-day\": f\"{now.day:02d}\",
   }
   post[\"metadata\"][\"annotations\"][\"content.halo.run/stats\"] = '{\"upvotes\":0,\"downvotes\":0,\"visits\":0}'
   post[\"metadata\"][\"annotations\"][\"content.halo.run/last-released-snapshot\"] = f\"snapshot-{slug}-{now.strftime('%Y%m%d')}\"
   post[\"metadata\"][\"annotations\"][\"checksum/content\"] = post[\"metadata\"][\"annotations\"][\"checksum/config\"]

   PUT /apis/content.halo.run/v1alpha1/posts/{name}
   ```

   **Verification:** After publishing, `GET /archives/{slug}` should return HTTP 200 with full HTML content including the article body. If the page renders but returns HTTP 404 status code instead of 200, this is a known Cloudflare/OpenResty proxy issue — the content IS served correctly (body has the page), but the status code is wrong. This does NOT affect user experience as browsers render the content normally.

6. **Contributor array empty**: Posts created via content API may have an empty `contributors` array even when `owner` is set. The console API create endpoint automatically adds the owner as a contributor. Compare:

   ```
   Console API (✅  works):  "contributors": [{"name":"wufeng", ...}]
   Content API (❌  404):    "contributors": []
   ```

   Fix by using the console API `POST` endpoint for initial creation, then fix owner via content API if needed.

7. **Snapshot not created (blank page)**: Halo 2.x does NOT store article content in `spec.htmlContent`. Instead, content lives in a **Snapshot** resource. The post references it via:
   - `spec.baseSnapshot` — base/original content snapshot UUID
   - `spec.headSnapshot` — current working draft snapshot UUID
   - `spec.releaseSnapshot` — published snapshot UUID (when `publish=true`)

   If you create a post without creating a corresponding Snapshot, the page will show title/header but the article body will be **completely blank**.

   **Note:** The post's `spec.htmlContent` field is **NOT USED** by Halo 2.x to render public pages. Even if you set it to a large HTML string, it will be ignored. Content is ONLY read from the linked Snapshot resource.

   **Complete Snapshot structure (with all required fields):**
   ```python
   snapshot_id = str(uuid.uuid4())
   snapshot_data = {
       "apiVersion": "content.halo.run/v1alpha1",
       "kind": "Snapshot",
       "metadata": {
           "name": snapshot_id,
           "annotations": {"content.halo.run/keep-raw": "true"}
       },
       "spec": {
           "contentPatch": html_content,       # rendered HTML
           "rawPatch": html_content,           # also the HTML (raw format)
           "rawType": "HTML",
           "owner": "wufeng",                   # same as post owner
           "contributors": ["wufeng"],          # must include owner
           "lastModifyTime": datetime.now(timezone.utc).isoformat(),
           "parentSnapshotName": "",
           "subjectRef": {
               "group": "content.halo.run",
               "kind": "Post",
               "name": post_name,               # post's metadata.name (slug)
               "version": "v1alpha1"
           }
       }
   }

   # Create via Content API
   POST /apis/content.halo.run/v1alpha1/snapshots
   # Or create/update via PUT:
   PUT /apis/content.halo.run/v1alpha1/snapshots/{snapshot_id}
   ```

   **After creating snapshot, update post to link it:**
   ```python
   post["spec"]["baseSnapshot"] = snapshot_id
   post["spec"]["headSnapshot"] = snapshot_id
   post["spec"]["releaseSnapshot"] = snapshot_id
   PUT /apis/content.halo.run/v1alpha1/posts/{name}
   ```

   **Order of operations for reliable content publication:**
   1. Console API POST to create draft (sets owner + contributor correctly)
   2. Create Snapshot with full HTML content + proper subjectRef
   3. Content API PUT to link snapshot (base/head/release) + fix labels + set publish=True
   4. Verify: `GET /archives/{slug}` should return 200 with full content

### Editor crashes / won't open post (white screen or empty editor)

If the Halo editor shows only the toolbar (buttons like "发布", "保存", "设置") but the ProseMirror content area never loads — the article is stuck in a state where the editor can't parse its content.

**Root cause:** The post's `metadata.annotations["content.halo.run/content-json"]` is set to `"true"`, which tells Halo "content is HTML/JSON", but the linked snapshot's `rawPatch` or `contentPatch` actually contains **Markdown** (starts with `#` headers, `**` bold, etc.). The editor tries to parse the content as HTML, fails silently, and never renders the ProseMirror editor.

**How it happens:**
- MCP `create_post` is called with markdown body → post created with `content-json: "true"` annotation
- No snapshot is created (or snapshot stores raw markdown)
- The post's `headSnapshot`/`baseSnapshot` point to a non-existent snapshot name, or contain the markdown as a string
- Halo reconciler goes into `inProgress: true` / `phase: DRAFT` limbo

**Diagnosis:**
```js
// From browser console on /console/posts — check phase
fetch('/apis/api.console.halo.run/v1alpha1/posts?page=1&size=20').then(r=>r.json()).then(d=>{
  d.items.forEach(i => console.log(i.post.spec.title, i.post.status?.phase))
});

// Check the snapshot content directly
(async () => {
  var r = await fetch('/apis/content.halo.run/v1alpha1/posts/post-name');
  var p = await r.json();
  // headSnapshot should be a UUID pointing to a Snapshot resource
  console.log('headSnapshot:', p.spec.headSnapshot);
  console.log('Is it a valid UUID?', /^[0-9a-f-]{36}$/.test(p.spec.headSnapshot));
  console.log('Or is it raw content?', p.spec.headSnapshot?.startsWith('#') || p.spec.headSnapshot?.startsWith('{'));
})();
```

**Fix — rebuild the post with proper snapshot:**

1. Delete the broken post + its ghost snapshots:
```js
// From browser console
await fetch('/apis/content.halo.run/v1alpha1/posts/post-name', {method:'DELETE'});
var snaps = await (await fetch('/apis/content.halo.run/v1alpha1/snapshots?page=1&size=20')).json();
for (var s of snaps.items||[]) {
  if (s.spec.subjectRef?.name === 'post-name') {
    await fetch('/apis/content.halo.run/v1alpha1/snapshots/'+s.metadata.name, {method:'DELETE'});
  }
}
```

2. Create a fresh post via the web UI "新建" button — this ensures the editor creates the correct snapshot format.

3. If creating via API, use the proper snapshot-first approach documented above in "Complete Working Workflow".

### Browser console double-escape pitfall

When constructing HTML content inside a browser console JavaScript string literal, escaped quotes (`\"`) in the JS string become literal backslash-quote characters (`\"`) in the stored data, not plain quotes (`"`). This breaks HTML parsing:

```js
// WRONG: backslashes end up in the stored HTML
snap.spec.contentPatch = '<pre><code class=\"language-bash\">npm install</code></pre>';
// Stored as: <pre><code class=\"language-bash\">npm install</code></pre>  ← broken!

// RIGHT: use single quotes for JS strings, no escaping needed
snap.spec.contentPatch = '<pre><code class="language-bash">npm install</code></pre>';
```

**Safe pattern:** Build the HTML content outside the JS console (e.g., with Python's `json.dumps`), then paste the clean JSON into a `var htmlContent = ...` assignment. Test that `JSON.parse(JSON.stringify(htmlContent)).raw` yields clean HTML without backslash artifacts.

### Dashboard count doesn't match visible posts

The stats endpoint counts ALL posts including:
- Ghost posts (deleted via UC API without `deleted` label)
- Drafts
- Recycled posts

Solution: Hard-delete via Content API, or add `content.halo.run/deleted=true` label.

### MCP `delete_post` returns success but post still exists

The MCP tool calls the UC API recycle endpoint which returns 200 even when it can't actually delete (e.g., PAT lacks permission). The actual deletion happens only for posts where the user is the owner. For ghost/empty-owner posts, use the Content API directly.

### 409 Conflict on Content API PUT (version mismatch)

When doing `PUT /apis/content.halo.run/v1alpha1/posts/{name}` after a GET, Halo may return **HTTP 409 Conflict**.

**Cause:** The post's internal revision counter changed between GET and PUT (common when a snapshot creation modified the post in the interim). Also, including the read-only `status` field in the PUT payload triggers this.

**Fix:**
```python
# Re-fetch the latest post state
req = urllib.request.Request(f"{base_url}/apis/content.halo.run/v1alpha1/posts/{name}", headers=headers)
post = json.loads(urllib.request.urlopen(req).read().decode())

# Apply modifications
post["spec"]["baseSnapshot"] = snapshot_id
post["spec"]["headSnapshot"] = snapshot_id
post["spec"]["publish"] = True

# CRITICAL: remove read-only 'status' field before PUT
post.pop("status", None)

# Retry
req2 = urllib.request.Request(
    f"{base_url}/apis/content.halo.run/v1alpha1/posts/{name}",
    data=json.dumps(post).encode(), headers=headers, method="PUT"
)
resp = urllib.request.urlopen(req2)
```

### Console API POST requires extra fields

When creating a draft via `/apis/api.console.halo.run/v1alpha1/posts`, Halo 2.25+ may return a 400 validation error if these fields are missing:

```json
"spec": {
  "deleted": false,    # REQUIRED
  "pinned": false,     # REQUIRED
  "priority": 0,       # REQUIRED
  ...
}
```

Without these three fields, the API rejects the request with:
```
spec: Field 'deleted' is required. (code: 1026)
spec: Field 'pinned' is required. (code: 1026)
spec: Field 'priority' is required. (code: 1026)
```

Always include `deleted: false`, `pinned: false`, `priority: 0` in any Console API POST body.

## References

See `references/mcp-protocol-pattern.md` for common MCP protocol interaction patterns (Python asyncio subprocess).
See `references/env-var-redaction.md` for the terminal env-var redaction issue and workarounds.
See `references/api-referral-content-strategy.md` for writing API relay tutorial articles for token-selling 引流 — tool selection, article structure, screenshot placeholders, and publishing flow.
See `references/browser-api-access.md` for using the browser's JS console to access Halo APIs when Cloudflare blocks external curl/python calls.
