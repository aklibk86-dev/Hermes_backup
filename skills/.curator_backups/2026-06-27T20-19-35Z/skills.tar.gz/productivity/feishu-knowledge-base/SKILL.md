---
name: feishu-knowledge-base
version: 1.0.0
description: "飞书知识库（Wiki）文档管理：通过 lark-cli 创建、更新、维护飞书知识库文档。适用于需要将技术文档、配置清单、API 手册等持久化保存到飞书知识库的场景。"
metadata:
  requires:
    bins: ["lark-cli"]
    services: ["Docker (lark-cli 通常运行在容器内)"]
  cliHelp: "lark-cli wiki +node-create --help; lark-cli docs +update --api-version v2 --help; lark-cli docs +create --api-version v2 --help"
---

# 飞书知识库文档管理

通过 lark-cli 管理飞书知识库（Wiki）文档。lark-cli 通常运行在 Docker 容器内（如 Hermes Agent 容器），通过 SSH 远程执行。

## 前置条件

1. **lark-cli 已配置认证**：运行 `lark-cli config init --new` 完成 OAuth 认证
2. **Feishu API 权限**：确保应用有 `wiki:space:retrieve`、`wiki:node:create`、`docx:document:update` 等权限
3. **知识库 Space ID**：通过 `lark-cli wiki +space-list --format pretty` 获取

## 工作流程

### 1. 查找 lark-cli

lark-cli 是 npm 包 `@larksuite/cli`，通常安装在 `/opt/data/home/.npm-global/bin/lark-cli` 或类似路径。

```bash
# 在容器内查找
find / -name "lark-cli" -type f 2>/dev/null | head -3

# 设置环境
export HOME=/opt/data/home
export PATH=/opt/data/home/.npm-global/bin:$PATH
```

### 2. 查看知识库列表

```bash
lark-cli wiki +space-list --format pretty
```

输出示例：
```
[1] 飞书知识库
    space_id:     7654947950363217077
    space_type:   team
    visibility:   public
```

### 3. 创建知识库文档节点

```bash
# 在知识库根目录创建
lark-cli wiki +node-create --space-id <SPACE_ID> --title "文档标题" --obj-type docx

# 在父节点下创建子节点
lark-cli wiki +node-create --space-id <SPACE_ID> --parent-node-token <PARENT_TOKEN> --title "子文档" --obj-type docx
```

返回结果包含 `node_token`（知识库节点标识）和 `obj_token`（文档对象标识）。

### 4. 写入文档内容（Markdown）

lark-cli 的 `docs +update --command overwrite` 可以覆盖已有文档的全部内容。

**推荐使用 stdin 管道传递内容**（避免 @file 路径问题）：

```bash
# 先准备 Markdown 内容到变量或文件
lark-cli docs +update --api-version v2 \
  --doc <DOC_TOKEN> \
  --command overwrite \
  --doc-format markdown \
  --content -
```

### 5. 在容器内执行的最佳实践

由于 lark-cli 通常运行在 Hermes Agent 容器内，通过远程 VPS 执行：

```bash
# 通过 SSH 在容器内执行
docker exec -i 1Panel-hermes-agent-UZQ9 bash -c "..."
```

**传递文件内容的可靠方式**：
1. SSH Paramiko exec_command 配合 `channel.send(content)` + `channel.shutdown_write()`
2. lark-cli 的 `--content -` 参数从 stdin 读取
3. `@file` 传参需要文件在容器的工作目录下，且只接受相对路径

**注意**：`@file` 只接受当前工作目录下的相对路径，绝对路径会报 `unsafe file path`。

## 常见操作

### 查看现有文档列表

```bash
lark-cli wiki +node-list --space-id <SPACE_ID> --parent-node-token <PARENT_TOKEN>
```

### 更新文档内容（追加）

```bash
lark-cli docs +update --api-version v2 \
  --doc <DOC_TOKEN> \
  --command append \
  --doc-format markdown \
  --content "新增内容"
```

### 局部替换

```bash
lark-cli docs +update --api-version v2 \
  --doc <DOC_TOKEN> \
  --command str_replace \
  --pattern "旧文本" \
  --content "新文本"
```

## 技术实现参考

通过 Python Paramiko 远程执行 lark-cli 的标准模式：

```python
import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(host, port=port, username=username, password=password, timeout=15)

lark = 'export HOME=/opt/data/home; export PATH=/opt/data/home/.npm-global/bin:$PATH'

# 通过 stdin 传递文档内容
transport = ssh.get_transport()
channel = transport.open_session()
channel.exec_command(
    f'docker exec -i 1Panel-hermes-agent-UZQ9 bash -c "{lark}; '
    f'lark-cli docs +update --api-version v2 --doc <TOKEN> '
    f'--command overwrite --doc-format markdown --content -"'
)
channel.send(markdown_content.encode())
channel.shutdown_write()
```

## Pitfalls

- **lark-cli 未配置**：首次使用需要运行 `lark-cli config init --new`，会输出验证 URL，打开后扫码完成认证
- **@file 路径限制**：`--content @file.md` 只接受相对路径，且文件必须在工作目录下
- **身份选择**：知识库操作通常用 `--as user`，bot 身份不支持 `my_library` 个人知识库
- **文档标题**：Markdown 格式创建文档时，`# 标题` 必须是内容开头的唯一一级标题，否则显示为 Untitled
- **Markdown 转义**：特殊字符（`*` `[` `]` `_` `\` `` ` `` `<` 等）在 Markdown 内容中必须转义
