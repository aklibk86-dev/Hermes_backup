---
name: feishu-cli
description: "Set up and configure lark-cli (飞书 CLI) for Hermes Agent — binding to existing Feishu apps, creating new apps, troubleshooting auth failures, and completing the user-authorization flow."
version: 1.0.0
author: agent
tags: [feishu, lark, lark-cli, auth, setup, hermes-integration]
---

# Feishu CLI (lark-cli) for Hermes Agent

Setup, configure, troubleshoot, and re-auth the lark-cli (飞书 CLI) integration with Hermes Agent. Required any time you need Feishu document/drive tools (`feishu_doc`, `feishu_drive`) to work from Hermes sessions.

## Prerequisites

- **npm** (for installing @larksuite/cli globally)
- **Hermes Agent** with Feishu gateway already configured (`hermes gateway setup`)
- User must be able to visit `https://open.feishu.cn/` in their browser

## Quick Reference

```bash
# Install
npm install -g @larksuite/cli

# Check available subcommands
lark-cli --help
lark-cli config --help
lark-cli auth --help
```

## Setup Workflow

### Step 1: Bind to Existing Hermes Feishu Connection

```bash
lark-cli config bind --source hermes --identity user-default --force
```

- `--identity bot-only` — safer, bot can only access bot resources
- `--identity user-default` — impersonates the user (needed for personal drive/docs)
- `--force` — required when switching from bot-only to user-default identity

This reads Hermes' existing Feishu app credentials and configures lark-cli to use them.

### Step 2: Authorize in Browser

```bash
lark-cli auth login --recommend
```

This prints a URL. The user MUST open this URL in **their own browser** on a separate machine (not via browser tools) to complete OAuth authorization. The command blocks until the user authorizes.

## When Binding Fails ("The specified app does not exist")

If Step 1 succeeds but Step 2 fails with:

```
"device authorization failed: The specified app does not exist."
```

The bound Feishu app has been deleted or has expired on Feishu's side. Three resolution paths:

### Path A: Create a Fresh Feishu App via CLI

```bash
# IMPORTANT: Remove stale local config first
rm -rf ~/.lark-cli/hermes

# Run init — this creates a new app on Feishu's backend
# and prints a link the user must visit
lark-cli config init --new --force-init
```

This prints ASCII art and a link like:
```
https://open.feishu.cn/page/cli?user_code=XXXX-XXXX&lpv=1.0.57&ocv=1.0.57&from=cli
```

The user visits the link and clicks confirm/create on the Feishu Open Platform page. **Tell the user to let you know when done** before continuing.

### Path B: Use Existing App Credentials Directly

If the user has the App ID and App Secret from an existing Feishu Open Platform app:

```bash
# Remove stale local config first
rm -rf ~/.lark-cli/hermes

# Configure with credentials via stdin (hides secret from process list)
echo "<app_secret>" | lark-cli config init \
  --app-id <app_id> \
  --app-secret-stdin \
  --force-init
```

This skips the browser setup page and writes the credentials directly. **The user must have already granted `drive:drive` and `docx:document` permissions** in the Feishu Open Platform console and published the app version.

### Path C: User Re-enables the Bound App on Feishu Platform

If the user says they've re-enabled permissions on the existing app, re-run the bind + auth flow:

```bash
lark-cli config bind --source hermes --identity user-default --force
# Then proceed to Step 2 (auth login)
```

## Authorization & QR Code

Two flows are available. Use the **non-blocking flow** when running as an AI agent — it avoids timeout issues by returning the verification URL immediately without blocking.

### Flow A: Non-Blocking (Recommended for AI Agents)

Get verification URL + device code immediately, no blocking:

```bash
lark-cli auth login --no-wait --json
```

Returns JSON with `device_code`, `expires_in`, and `verification_url`:

```json
{
  "device_code": "OzEDz8U_F1Xz...",
  "expires_in": 600,
  "verification_url": "https://accounts.feishu.cn/oauth/v1/device/verify?flow_id=...&user_code=XXXX-XXXX"
}
```

Then:
1. Generate QR code: `lark-cli auth qrcode "<verification_url>" --output /tmp/feishu_auth_qr.png`
2. Deliver URL + QR image to user (via MEDIA:)
3. Tell the user to notify you when authorization is complete
4. After user confirms, complete the flow:
   ```bash
   lark-cli auth login --device-code "<device_code>"
   ```

**CRITICAL timing rule:** Do NOT run `--no-wait --json` and `--device-code` in the same turn. Wait for the user to explicitly confirm authorization first. Running `--device-code` before the user finishes blocks for up to 10 minutes. Each `--no-wait --json` call generates a fresh device_code — the previous one expires.

### Flow B: Blocking (Simple, May Time Out)

```bash
lark-cli auth login --recommend
```

Prints URL then blocks until user authorizes. For AI agent use:
- Run in background with timeout >= 120s and notify_on_complete=true
- Capture URL from output (may need redirect `2>&1`)
- Generate QR code, deliver to user
- Wait for background notification

### QR Code Generation

```bash
# PNG (preferred)
lark-cli auth qrcode "<verification_url>" --output /tmp/feishu_auth_qr.png

# ASCII (only if user explicitly requests)
lark-cli auth qrcode "<verification_url>" --ascii
```

Generating the QR file alone is NOT enough — the lark-cli instruction requires displaying the image in your response. Use MEDIA:/path/to/file to attach it.

### Important notes (both flows)
- User must open URL in their own browser (not via Hermes browser tools)
- The URL is an opaque string — do NOT URL-encode/decode or modify it
- Do not cache verification_url or device_code for future use — always run fresh
- `auth login --recommend` output to stdout may buffer in background mode; redirect with `2>&1`

## Pitfalls

### Command Times Out Waiting for User

`lark-cli config init` and `lark-cli auth login` both **block indefinitely** waiting for the user to complete the browser step. The default foreground timeout (60s) is too short.

**Preferred solution:** Use the non-blocking `--no-wait --json` flow described above to get the URL immediately without blocking.

**If you must use blocking mode:**
- Run in background with `notify_on_complete`:
  ```terminal
  terminal(command="lark-cli auth login --recommend 2>&1", background=true, notify_on_complete=true, timeout=300)
  ```
- Or run in foreground with a short timeout (15-30s) to capture the link, then re-run as background for the blocking wait.

### Device Code Timing Trap

If you use `--no-wait --json` to get the verification URL, do NOT run `--device-code` in the same response turn. Wait for the user to reply "done" or "ok" first. Running `--device-code` in the same turn while the user is still authorizing blocks for up to 10 minutes. Use the two-turn pattern:

Turn 1: Get URL + QR → deliver to user → ask them to notify you when done
Turn 2 (after user says done): Run `--device-code`

### Background Mode Swallows Output

When run as a background process, lark-cli's stdout may be buffered and produce no output in the tool log. If you see no output after starting:
1. Kill the background process
2. Run in foreground with a short timeout (15-30s) to get the link
3. Then run again in background for the blocking wait

### Old Config Blocks New Init

If `--force-init` ran before but timed out, the broken local config remains at `~/.lark-cli/hermes/`. **Always remove it before re-initiating:**
```bash
rm -rf ~/.lark-cli/hermes
```

### User Codes Expire

Each `config init` generates a fresh user_code. If the user visits a stale link (from a previous run), the code will be invalid. Always give the user the **latest** link.

## Verification

After successful setup, verify with:
```bash
lark-cli auth whoami
```

This should return the authenticated Feishu user's identity.

## References

See `references/error-patterns.md` for exact error messages and recovery recipes.
See `references/hermes-integration.md` for Hermes-specific config paths and profile considerations.
