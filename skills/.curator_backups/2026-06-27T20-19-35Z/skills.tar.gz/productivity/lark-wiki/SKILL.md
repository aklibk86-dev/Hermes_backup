---
name: lark-wiki
description: "Manage Feishu/Lark wiki (knowledge base) documents: create wiki nodes, populate them with Markdown content, and organize documentation. Covers running lark-cli inside the Hermes agent Docker container via SSH, creating wiki pages under parent nodes, and writing content via stdin pipe."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [productivity, feishu, lark, wiki, knowledge-base, documentation]
    related_skills: [remote-ssh-access, 1panel-docker-deploy]
---

# Lark Wiki (飞书知识库)

## When to Use

- User asks to save information to a Feishu knowledge base (知识库/飞书知识库)
- User asks to create documentation pages in Feishu wiki
- You need to organize VPS service docs, API references, or configuration guides into Feishu
- Post-deployment step: after setting up a service, save the config to the knowledge base

## Prerequisites

- SSH access to the VPS (see `remote-ssh-access` skill)
- The Hermes agent container (`1Panel-hermes-agent-UZQ9`) running on the VPS
- lark-cli must be installed and configured inside that container
- Node.js available inside the container (needed for lark-cli)

## Architecture

The lark-cli binary lives in the Hermes agent Docker container. To use it, you SSH into the VPS, then run commands inside the container via `docker exec`.

Key paths inside the Hermes agent container:
- `HOME=/opt/data/home` (the hermes user's home)
- `PATH=$PATH:/opt/data/home/.npm-global/bin` (where lark-cli symlink lives)
- lark-cli config: `/opt/data/home/.lark-cli/hermes/config.json`

The lark-cli was authenticated as the user `吴艳彬` (Feishu account) with app ID `cli_aabc5fb2af38dccd`.

## Step-by-Step

### 1. Setup the lark-cli environment

When running commands inside the container, always set the correct environment:

```bash
# Common prefix for all lark-cli commands
LARK="export HOME=/opt/data/home; export PATH=/opt/data/home/.npm-global/bin:$PATH"
```

### 2. List existing wiki spaces

```python
import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(HOST, port=PORT, username='root', password=PASSWORD, timeout=15)

stdin, stdout, stderr = ssh.exec_command(
    'docker exec 1Panel-hermes-agent-UZQ9 bash -c '
    '"export HOME=/opt/data/home; export PATH=/opt/data/home/.npm-global/bin:$PATH; '
    'lark-cli wiki +space-list --format pretty"',
    timeout=15
)
print(stdout.read().decode().strip())
```

Typical output:
```
[1] 飞书知识库
    space_id:     7654947950363217077
    space_type:   team
```

### 3. Create a wiki node (document)

```python
space_id = '7654947950363217077'
lark = 'export HOME=/opt/data/home; export PATH=/opt/data/home/.npm-global/bin:$PATH'

# Create under root
cmd = f'docker exec 1Panel-hermes-agent-UZQ9 bash -c "{lark}; lark-cli wiki +node-create --space-id {space_id} --title \\"My Document\\" --obj-type docx"'

# Create under a parent node
cmd = f'docker exec 1Panel-hermes-agent-UZQ9 bash -c "{lark}; lark-cli wiki +node-create --space-id {space_id} --parent-node-token {parent_token} --title \\"Sub Document\\" --obj-type docx"'
```

The response includes:
- `node_token` - The wiki node token (used as `--doc` for content operations)
- `obj_token` - The actual document token
- `url` - Direct URL to the document

### 4. Write content to a document

Use `docs +update --command overwrite --doc-format markdown` with stdin pipe to populate a document:

```python
import paramiko, time

ssh = paramiko.SSHClient()
ssh.connect(HOST, port=PORT, username='root', password=PASSWORD, timeout=15)

# Read the markdown content
content = """# My Document Title
## Section 1
Content here...
"""

# Pipe content via stdin (-) into the document
transport = ssh.get_transport()
channel = transport.open_session()
channel.exec_command(
    'docker exec -i 1Panel-hermes-agent-UZQ9 bash -c '
    '"export HOME=/opt/data/home; export PATH=/opt/data/home/.npm-global/bin:$PATH; '
    'lark-cli docs +update --api-version v2 --doc DOC_TOKEN '
    '--command overwrite --doc-format markdown --content -"'
)
channel.send(content.encode())
channel.shutdown_write()
time.sleep(3)
result = channel.recv(4096).decode()
print(result)
```

**Key points about content**: The `--doc-format markdown` flag accepts standard Markdown. Use `--doc` with the `obj_token` (not `node_token`) from step 3. The `-` parameter for `--content` reads from stdin.

### 5. Using @file instead of stdin

You can also write the content to a file inside the container and use the `@file` syntax:

```python
# SCP file to VPS host
sftp = ssh.open_sftp()
with sftp.open('/tmp/content.md', 'w') as f:
    f.write(markdown_content)
sftp.close()

# Copy into container
ssh.exec_command('docker cp /tmp/content.md 1Panel-hermes-agent-UZQ9:/opt/hermes/')

# Update from file (must use cwd where file lives)
cmd = f'docker exec 1Panel-hermes-agent-UZQ9 bash -c "{lark}; cd /opt/hermes && lark-cli docs +update --api-version v2 --doc DOC_TOKEN --command overwrite --doc-format markdown --content @content.md"'
```

**Important**: The `@file` path must be relative to the container's working directory (default: `/opt/hermes`). Absolute paths will fail with `unsafe file path` error.

## Best Practice: The Stdin Pipe Pattern

The stdin pipe method (`--content -`) is the most reliable way to write content. It avoids:
- File path issues (`@file` fails with absolute paths)
- Shell escaping problems (heredoc with special characters)
- Permission issues (writing files as root vs running as hermes user)

Full deploy pattern:

```python
ssh = paramiko.SSHClient()
ssh.connect(HOST, port=PORT, username='root', password=PASSWORD, timeout=15)
lark = 'export HOME=/opt/data/home; export PATH=/opt/data/home/.npm-global/bin:$PATH'

# 1. Create wiki node
stdin, stdout, stderr = ssh.exec_command(
    f'docker exec 1Panel-hermes-agent-UZQ9 bash -c "{lark}; lark-cli wiki +node-create --space-id SPACE_ID --parent-node-token PARENT --title \\"Doc Title\\" --obj-type docx"',
    timeout=15
)
# Extract node_token from JSON output
import json
result = json.loads(stdout.read().decode().strip())
doc_token = result['data']['obj_token']  # Use obj_token for content operations

# 2. Write content via stdin
transport = ssh.get_transport()
channel = transport.open_session()
channel.exec_command(
    f'docker exec -i 1Panel-hermes-agent-UZQ9 bash -c "{lark}; lark-cli docs +update --api-version v2 --doc {doc_token} --command overwrite --doc-format markdown --content -"'
)
channel.send(md_content.encode())
channel.shutdown_write()
time.sleep(2)
```

## Reusable Python Wrapper

For scripts that need to create and write multiple wiki documents, use this pattern:

```python
#!/opt/hermes/.venv/bin/python3
import paramiko, time, json

HOST = '149.104.8.237'
PORT = 37926
PASSWORD = 'VPS_ROOT_PASSWORD'  # from memory
SPACE_ID = '7654947950363217077'  # from memory

lark = 'export HOME=/opt/data/home; export PATH=/opt/data/home/.npm-global/bin:$PATH'

def wiki_create(ssh, title, parent_token=None):
    """Create a wiki node and return its obj_token."""
    cmd = f'docker exec 1Panel-hermes-agent-UZQ9 bash -c "{lark}; lark-cli wiki +node-create --space-id {SPACE_ID}'
    if parent_token:
        cmd += f' --parent-node-token {parent_token}'
    cmd += f' --title \\"{title}\\" --obj-type docx"'
    
    stdin, stdout, stderr = ssh.exec_command(cmd, timeout=15)
    result = json.loads(stdout.read().decode().strip())
    return result['data']['obj_token'], result['data']['node_token']

def wiki_write(ssh, doc_token, md_content):
    """Write Markdown content to a wiki document via stdin pipe."""
    transport = ssh.get_transport()
    channel = transport.open_session()
    channel.exec_command(
        f'docker exec -i 1Panel-hermes-agent-UZQ9 bash -c "{lark}; lark-cli docs +update --api-version v2 --doc {doc_token} --command overwrite --doc-format markdown --content -"'
    )
    channel.send(md_content.encode())
    channel.shutdown_write()
    time.sleep(2)
    return channel.recv(4096).decode()

# Usage
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(HOST, port=PORT, username='root', password=PASSWORD, timeout=15)

# Create parent folder
parent_doc, parent_node = wiki_create(ssh, '运维文档')
# Create child under parent
child_doc, child_node = wiki_create(ssh, 'API文档', parent_token=parent_node)
# Write content
result = wiki_write(ssh, child_doc, '# API Documentation\\n...')

ssh.close()
```

## Command Reference

| Action | Command | Notes |
|--------|---------|-------|
| List spaces | `lark-cli wiki +space-list --format pretty` | Returns space_id |
| Create node | `lark-cli wiki +node-create --space-id X --title "T" --obj-type docx` | Returns node_token, obj_token |
| Create child node | `... --parent-node-token P --title "T"` | Parent must already exist |
| Read doc content | `lark-cli docs +fetch --api-version v2 --doc TOKEN --doc-format markdown` | Use obj_token |
| Write doc content | `lark-cli docs +update --api-version v2 --doc TOKEN --command overwrite --doc-format markdown --content -` | Use stdin pipe with `-` |
| Append to doc | `... --command append --content -` | Adds content to end |
| Insert after block | `... --command block_insert_after --block-id X --content -` | For precise editing |

## References

- `references/lark-wiki-workflow.md` — Full session transcript and error recovery examples

## Pitfalls

1. **Wrong token type**: `wiki +node-create` returns both `node_token` and `obj_token`. Use `obj_token` (or `document.obj_token` depending on response shape) for `docs +update --doc`. Using `node_token` will fail because it's a wiki node, not a document.
2. **@file path restriction**: The `@file` syntax only accepts relative paths from the container's working directory. Absolute paths (e.g., `@/tmp/file.md`) fail with `unsafe file path`. Either: (a) copy files to the container's cwd (`/opt/hermes/`), or (b) use stdin pipe (`--content -`).
3. **Directory mismatch**: The container's `docker exec` default cwd (`/opt/hermes`) is not the same as `$HOME` (`/opt/data/home`). Always set both `HOME` and `PATH` explicitly.
4. **Stdin pipe cleanup**: After `channel.shutdown_write()`, wait at least 2 seconds before reading the response (`channel.recv()`). The lark-cli takes a moment to process stdin data before writing the response.
5. **Node.js required**: lark-cli is a Node.js script. If the container lacks `node`, the command fails with `env: 'node': No such file or directory`. The Hermes agent container has Node v22.22.3.
6. **Title truncation with Chinese characters**: When passing titles with Chinese characters through bash `-c`, single quotes around the title may be mangled by the outer command string. Use double-escaped quotes or avoid special characters in titles.
7. **SSH timeout on long content**: Large Markdown content sent via stdin may cause the SSH channel to timeout. Set generous timeouts (30s+) for documents over 50KB.
