# Lark Wiki Workflow — Session Notes

## Initial Setup (One-Time)

This VPS has a Hermes agent container (`1Panel-hermes-agent-UZQ9`) that has lark-cli installed and authenticated.

### Verify lark-cli is available

```bash
# From the VPS, check inside the container
docker exec 1Panel-hermes-agent-UZQ9 bash -c \
  "export HOME=/opt/data/home; export PATH=/opt/data/home/.npm-global/bin:\$PATH; lark-cli --version"
# Expected: lark-cli version 1.0.57
```

### Verify authentication

```bash
docker exec 1Panel-hermes-agent-UZQ9 bash -c \
  "export HOME=/opt/data/home; export PATH=/opt/data/home/.npm-global/bin:\$PATH; lark-cli auth whoami"
```

### Check existing config

The lark-cli config file is at: `/opt/data/home/.lark-cli/hermes/config.json`

```json
{
  "apps": [{
    "appId": "cli_aabc5fb2af38dccd",
    "brand": "feishu",
    "users": [{
      "userOpenId": "ou_1671478684d215bae21a91fbdfd29157",
      "userName": "吴艳彬"
    }]
  }]
}
```

## VPS Connection Details

- Host: 149.104.8.237
- SSH Port: 37926
- User: root
- Password: ecwoVMLX4252
- Container: 1Panel-hermes-agent-UZQ9
- lark-cli path: /opt/data/home/.npm-global/bin/lark-cli (symlink)

## Wiki Space Info

- Space name: 飞书知识库
- Space ID: 7654947950363217077
- Space type: team (public)

## Known Parent Node Tokens

| Title | Node Token |
|-------|-----------|
| 运维文档 (root) | M6VIwuMnXiPOVzkXvt6ceSvZnZf |

## Known Document Tokens

| Title | obj_token | URL |
|-------|-----------|-----|
| Komari API 文档 | P5RPdkcEIomOuRxp3g1c6unyndb | https://rcn4xp25thz3.feishu.cn/wiki/UaDSwIwo3iG1zSkze62cPKbBnLK |
| Komari Agent 开发文档 | VtXYdAHRgo2kdSxm7zQcA8pen4e | https://rcn4xp25thz3.feishu.cn/wiki/JLAFwwJNhiHnM2knB5GcOoUWnVf |
| VPS 服务清单与配置 | Q3oOdXeeKopIKJxlEU4cBDD5nAf | https://rcn4xp25thz3.feishu.cn/wiki/GkUiw1uk4isMk6keuutc7wQbnkd |

## Error Recovery

### "not configured" error

```
{"ok": false, "error": {"type": "config", "subtype": "not_configured", "message": "not configured"}}
```

**Fix**: Run `lark-cli config init --new` to generate an authentication URL. Open the URL in a browser and complete the OAuth flow. This was already done in a previous session for this environment.

### "@file cannot read file"

```
error: "--content: cannot read file \"file.md\": open /opt/hermes/file.md: no such file or directory"
```

**Fix**: The `@file` path must be relative to the container's working directory. Either:
1. Copy the file to the cwd: `docker cp /tmp/file.md 1Panel-hermes-agent-UZQ9:/opt/hermes/` then use `@file.md`
2. Use stdin pipe: `--content -` and pipe content through `channel.send()`
3. Change to the file's directory first: `cd /tmp && lark-cli ... --content @file.md`

### JSON parsing error on response

When a command returns valid JSON embedded inside other text (like "Creating wiki node..." prefix), strip the non-JSON prefix or use `grep -o '{.*}'` before parsing.
