---
name: feishu-drive-cli
category: productivity
description: Install, configure, and use lark-cli (@larksuite/cli) to create Feishu/Lark documents, upload files, and manage permissions via OAuth device flow.
triggers:
  - "飞书文档"
  - "feishu doc"
  - "飞书云盘"
  - "lark doc"
  - "飞书上传"
  - "飞书权限"
  - "lark-cli"
  - "larksuite"
  - "飞书CLI"
  - "飞书文档导入"
  - "飞书文档权限"
  - "feishu drive"
  - "创建飞书文档"
---

# feishu-drive-cli — lark-cli 飞书文档与云盘操作

Use [@larksuite/cli](https://open.feishu.cn/document/no_class/mcp-archive/feishu-cli-installation-guide.md) (npm package `@larksuite/cli`, binary `lark-cli`) to interact with Feishu/Lark Drive, documents, and permissions from the terminal.

## Installation

### Prerequisites
- Node.js v18+ (check with `node --version`)
- npm (comes with Node.js)

### Install CLI
```bash
npm install -g @larksuite/cli
```

If EACCES (permission denied on `/usr/local/lib/node_modules`), install to a local prefix:
```bash
npm config set prefix "$HOME/.npm-global"
mkdir -p "$HOME/.npm-global"
export PATH="$HOME/.npm-global/bin:$PATH"
npm install -g @larksuite/cli
# Add to bashrc for persistence:
echo 'export PATH="$HOME/.npm-global/bin:$PATH"' >> ~/.bashrc
```

Verify:
```bash
lark-cli --version
```

### Install Feishu Skills (recommended)
```bash
npx -y skills add https://open.feishu.cn --skill -y
```
This installs 27 lark-* skills covering drive, doc, IM, calendar, sheets, etc. into `.agents/skills/`.

## Configuration

### Option A: Bind to Existing Feishu App (Hermes Gateway)
If Hermes already has a Feishu connection (FEISHU_APP_ID in .env):
1. Confirm intent + identity with user (`bot-only` or `user-default`)
2. Run:
```bash
lark-cli config bind --source hermes --identity user-default --force
```
3. Then authenticate (see Auth section below)

### Option B: Configure with App ID + App Secret Directly
```bash
echo "<APP_SECRET>" | lark-cli config init --app-id <APP_ID> --app-secret-stdin --force-init
```

### Option C: Create a New Feishu App
```bash
lark-cli config init --new --force-init
```
This generates a browser URL. Give it to the user to complete setup in Feishu Open Platform.

## Authentication (OAuth Device Flow)

### Get verification URL + QR code (recommended — non-blocking)
```bash
# Get the device code and URL
lark-cli auth login --recommend --no-wait --json
```

Extract `verification_url` from JSON output. Generate a QR code:
```bash
lark-cli auth qrcode "<verification_url>" --output /tmp/feishu_qr.png
```

Show the URL and MEDIA:/tmp/feishu_qr.png to the user. Tell them to open the URL or scan the QR code in browser.

### Complete authorization
After user confirms they've authorized:
```bash
lark-cli auth login --device-code "<device_code>"
```

### Verify
```bash
lark-cli auth status
```

## Common Operations

### Import a Word/Excel/MD file as Feishu Doc
```bash
# cd to file's directory first (--file only accepts relative paths)
cd /path/to/file/dir
lark-cli drive +import --file "./filename.docx" --type docx --name "文档标题"
```
Supported types: `docx`, `sheet`, `bitable`, `slides`

### Upload a file to Drive
```bash
cd /path/to/file/dir
lark-cli drive +upload --file "./file.pdf"
```

### Set Public Permission (link sharing)
```bash
lark-cli drive permission.public patch \
  --token "<doc_token>" \
  --type docx \
  --yes \
  --data '{"link_share_entity":"tenant_readable","comment_entity":"anyone_can_view","security_entity":"anyone_can_view","share_entity":"only_full_access"}'
```

`link_share_entity` options:
- `tenant_readable` — org members with link can read
- `tenant_editable` — org members with link can edit
- `anyone_readable` — internet with link can read (requires external_access=true)
- `anyone_editable` — internet with link can edit (requires external_access=true)
- `closed` — disable link sharing

### Add Collaborator
```bash
lark-cli drive permission.members create \
  --token "<doc_token>" \
  --type docx \
  --yes \
  --data '{"member_id":"<id>","member_type":"appid","perm":"full_access"}'
```

`member_type` options: `email`, `openid`, `unionid`, `openchat`, `opendepartmentid`, `userid`, `groupid`, `wikispaceid`, `appid`
`perm` options: `view`, `edit`, `full_access`

### Check document info
```bash
lark-cli drive +inspect <doc_url_or_token>
```

## Scopes (Permissions) Required
For document import + permission management:
- `drive:file:upload` — upload files
- `docs:document:import` — import files as docs
- `docs:permission.setting:write_only` — change permission settings
- `docs:permission.member:create` — add collaborators
- `docx:document:create` — create documents

Users grant these during the OAuth device flow. The `--recommend` flag suggests the minimum required scopes.

## Pitfalls
1. **Absolute paths not accepted**: `--file` requires a relative path. Always `cd` to the target directory first.
2. **Device codes expire**: verification URLs and device codes expire after ~600 seconds (10 min). If it expires, re-run `auth login --no-wait --json` for a fresh one.
3. **Don't block on auth**: Use `--no-wait --json` to get the URL, show it to the user, then wait for their confirmation before calling `--device-code`.
4. **The app must have permissions enabled**: In Feishu Open Platform, the app needs the relevant scopes added in "Permissions" → "Add permissions" → publish the app version.
5. **lark-cli config vs Hermes config**: The lark-cli workspace is separate from Hermes config. Changes to one don't update the other — re-run `config bind` if Hermes credentials change.

## References
- Official guide: https://open.feishu.cn/document/no_class/mcp-archive/feishu-cli-installation-guide.md
- GitHub: https://github.com/larksuite/cli
