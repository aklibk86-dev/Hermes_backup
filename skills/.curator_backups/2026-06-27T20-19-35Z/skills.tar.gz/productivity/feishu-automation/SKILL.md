---
name: feishu-automation
category: productivity
description: "Upload, import, and manage Feishu (Lark) documents using lark-cli (@larksuite/cli). Covers installation, binding to Hermes Feishu gateway, OAuth device auth flow, importing docx/sheets as cloud documents, managing collaborators and public permissions. Not for reading/replying to existing documents (use the built-in feishu_doc/feishu_drive tools instead)."
version: 1.0.0
author: Hermes Agent
license: MIT
triggers:
  - feishu
  - lark
  - 飞书
  - upload to feishu
  - feishu document
  - lark-cli
  - 飞书文档
  - 上传到飞书
---

# Feishu Automation (lark-cli)

## Overview

Feishu (Lark) automation via `@larksuite/cli` — the official Feishu CLI tool (`lark-cli`). Use this when the user asks to create, upload, import, or share Feishu documents that require Open API access beyond the built-in `feishu_doc_read` / `feishu_drive_add_comment` tools (which only support read/comment operations).

## Installation

```bash
# Install globally
npm install -g @larksuite/cli

# If EACCES on global install, set local prefix:
npm config set prefix "$HOME/.npm-global"
export PATH="$HOME/.npm-global/bin:$PATH"
npm install -g @larksuite/cli

# Verify
lark-cli --version
```

Add PATH to bashrc for persistence: `echo 'export PATH="$HOME/.npm-global/bin:$PATH"' >> ~/.bashrc`

## Binding to Existing Hermes Feishu App

### Option A: Bind to the existing Hermes Feishu gateway app (recommended)

The Hermes Feishu gateway already has an app configured in `.env` (`FEISHU_APP_ID`, `FEISHU_APP_SECRET`). Bind lark-cli to it with user-default identity so it can impersonate the user:

```bash
lark-cli config bind --source hermes --identity user-default --force
```

Then authenticate via OAuth device flow (see Auth section below).

### Option B: Create a new Feishu app (fallback)

If binding fails with "app does not exist", create a fresh app:

```bash
lark-cli config init --new --force-init
```

This outputs a URL — the user must open it in their browser to create the app on Feishu Open Platform. After they confirm, run auth login.

## OAuth Authentication (Device Flow)

The auth process requires user interaction in their browser. Do NOT block on the login command — use the non-blocking flow:

### Step 1: Get verification URL and device code

```bash
lark-cli auth login --no-wait --json
```

Returns `verification_url` and `device_code`. Also returns a hint to generate a QR code.

### Step 2: Generate QR code (mandatory)

```bash
lark-cli auth qrcode "<verification_url>" --output /tmp/feishu_auth_qr.png
```

### Step 3: Show user the URL and QR code

Send both to the user. Tell them to open the URL or scan the QR code, authorize in their browser, and come back.

### Step 4: Complete authorization

After the user confirms they've authorized:

```bash
lark-cli auth login --device-code "<device_code>"
```

This polls the auth endpoint and completes the token exchange. Expected output includes the user's name and open_id (e.g. `ou_1671478684d215bae21a91fbdfd29157`).

**IMPORTANT:** Do NOT cache verification_url or device_code across sessions. Always run `--no-wait --json` fresh. Each call invalidates the previous device code.

**IMPORTANT:** Must generate and display a QR code — it's a required step by the lark-cli auth flow. Prefer PNG (`--output`), fall back to ASCII (`--ascii`) only if the user explicitly asks for it.

## Common Operations

### Import a local file as a Feishu cloud document

```bash
# cd to the file's directory first (lark-cli requires relative paths)
cd /path/to/file/dir
lark-cli drive +import --file "./filename.docx" --type docx --name "Document Title" --format pretty
```

Supported types: `docx`, `sheet`, `bitable`, `slides`. Returns a `token` and `url`.

### Set public sharing (anyone with link can read)

The default after import is tenant-only. To make it publicly accessible without login:

```bash
lark-cli drive permission.public patch --token "<token>" --type docx --yes \
  --data '{"link_share_entity":"anyone_readable","external_access":true,"comment_entity":"anyone_can_view","security_entity":"anyone_can_view","share_entity":"only_full_access"}'
```

### Add a collaborator (app bot) with edit permission

```bash
lark-cli drive permission.members create --token "<token>" --type docx --yes \
  --data '{"member_id":"<app_id>","member_type":"appid","perm":"full_access"}'
```

The app_id is the one Hermes uses (from `.env`: `FEISHU_APP_ID`).

### Verify setup

```bash
lark-cli auth status          # check current auth state
lark-cli drive +inspect --url "https://...feishu.cn/docx/<token>"   # inspect a document
```

## Pitfalls

1. **auth login with `--recommend` blocks forever** — Always use `--no-wait --json` to get the URL as non-blocking JSON, then `--device-code` after user confirms.

2. **device code expires** — The device code has a 600-second (10 min) expiry. If the user takes too long, run `--no-wait --json` again to get a fresh one.

3. **Verification URL is opaque** — Do NOT modify, URL-encode, or add punctuation to the `verification_url` string. Pass it verbatim to `lark-cli auth qrcode` and to the user.

4. **QR code is mandatory** — The lark-cli auth flow requires the agent to generate and display a QR code. Not generating one breaks the authentication contract.

5. **Relative paths only** — `lark-cli drive +import --file` requires a relative path within the current working directory. `cd` first, then use `./filename.docx`.

6. **Permission changes after import** — Imported documents default to organization-internal sharing only. Explicitly set `link_share_entity` and `external_access` for public access.

7. **Multiple DevOps tools may conflict** — The Feishu app used by Hermes gateway may not have Open API scopes enabled. If `auth login` fails with "app does not exist", the user needs to enable `drive:drive`, `docx:document`, and `docs:permission.member:create` scopes in the Feishu Open Platform console.