---
name: ai-api-relay
category: mlops-inference
description: Configuration, pricing, and management of self-hosted AI API relay stations (New-API, OneAPI). Covers dual rate multiplier architecture, pricing strategy, and plan-first user workflow.
triggers:
  - new-api
  - oneapi
  - api relay
  - ai api proxy
  - relay station
  - 中转站
  - api pricing
  - rate multiplier
  - 倍率
---

# AI API Relay Station Management

Guide to configuring, pricing, and managing self-hosted AI API relay stations (New-API, OneAPI, etc.).

## User Preference: Plan-First Approach

When modifying a user's relay station or server configuration:

1. **First present a plan** with clear options, costs, and trade-offs — DO NOT modify anything until the user chooses
2. **Wait for explicit approval** before making changes
3. If the user says "just give me the plan, I'll do it myself": immediately revert any in-progress changes and provide complete step-by-step documentation
4. Provide the documentation in a format the user can follow independently (exact commands, UI paths, screenshots if needed)
5. Never modify production pricing/settings without the user choosing from options first

## New-API (calciumion/new-api) Architecture

### Containers
| Container | Purpose |
|-----------|---------|
| `new-api` | Main application (Go), port 3000 |
| `new-api-postgres` | PostgreSQL database (user: `newapi`) |
| `new-api-redis` | Redis cache |

### Configuration Storage
- Most settings stored in `options` table as key-value pairs
- Table schema: `key` (text), `value` (text — often JSON)

### Key Database Options
| Key | Description | Format |
|-----|-------------|--------|
| `TopupGroupRatio` | Top-up credit multiplier per group | JSON: `{"group": multiplier}` |
| `ModelRatio` | Per-model pricing ratio | Large JSON |
| `ModelPrice` | Per-model base prices | JSON |
| `Chats` | Chat settings | JSON |
| `ServerAddress` | Server address | text |

## Two Rate Settings in New-API

New-API has TWO independent rate multipliers — they are NOT the same and affect pricing differently.

### 1. TopupGroupRatio (充值倍率)

Control how many credits users get when they top up. Stored in DB `options` table, key `TopupGroupRatio`. Format: `{"default": 2, "svip": 1, "vip": 1.5}`. User pays $20 → gets $20 × multiplier credits. Modify via SQL or Operation tab in Settings UI.

### 2. Group Ratio (消费倍率 / Billing Multiplier)

Control how fast credits are consumed per token. Located in Admin UI: System → Group & Model Pricing → Group Related Settings. Default: 1.0 (no markup). Model costs × Group Ratio = actual deduction. Modify via spinbutton in Group Management grid.

**⚠️ The UI "Ratio" field is NOT the same as TopupGroupRatio. They are stored independently.**

## Pricing Calculation Formula

User pays 10元 → gets $20 base × TopupGroupRatio credits → consumes at ModelPrice × ModelRatio × GroupRatio → your upstream cost = tokens consumed × (your cost per $1). Profit = user payment - upstream cost.

### Margin Analysis (upstream: 10元 = $20)

| TopupGroupRatio | GroupRatio | Result on $20 top-up |
|---|---|---|
| 2.0 | 1.0 | -10元 (loss — gives $40 for $20 cost) |
| 1.5 | 1.5 | 0元 (break-even) |
| 1.0 | 1.5 | +3.3元 (profitable) |
| 0.7 | 1.0 | +3元 (profitable) |

## Common SQL Operations

### Modify TopupGroupRatio
```sql
UPDATE options SET value = '{"default": 1.5, "svip": 1, "vip": 1.5}' WHERE key = 'TopupGroupRatio';
```

After DB changes, restart to apply:
```bash
docker restart new-api
```

### Verify Changes
```bash
docker exec -i new-api-postgres psql -U newapi -d new-api -t -A -c "SELECT value FROM options WHERE key = 'TopupGroupRatio'"
docker exec -i new-api-postgres psql -U newapi -d new-api -t -A -c "SELECT username, \"group\" FROM users"
docker exec -i new-api-postgres psql -U newapi -d new-api -t -A -c "SELECT key FROM options ORDER BY key"
```

### DB Connection Discovery
```bash
docker exec new-api-postgres printenv | grep POSTGRES
```

## UI Navigation Path (Group Ratio)

Console → System → Group & Model Pricing tab → Group Related Settings sub-tab → edit the "Ratio" spinbutton for the default group

## Pricing Templates

| Template | TopupGroupRatio | GroupRatio | Result |
|---|---|---|---|
| Break-even (attract) | 1.5 | 1.5 | Zero profit |
| Profitable | 1.0 | 1.5 | ~33% margin |
| Topup-only | 0.7 | 1.0 | ~30% margin |

## Reference Files

| File | Covers |
|------|--------|
| `references/market-pricing-and-listings.md` | Official model prices, 闲鱼 market pricing, pricing strategy, and listing copy templates for selling API relay services |

## Pitfalls
- The two rate settings are easily confused — always specify which one
- After SQL changes, restart: `docker restart new-api`
- PostgreSQL quoting: use `\"group\"` for the reserved word
- DB password is in container env (`POSTGRES_PASSWORD`), not in config files
- Rate changes only affect new top-ups and future consumption, not existing balances